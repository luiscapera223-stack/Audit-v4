/* Audit Follow Up v4 — frontend (data dari server SQLite, dengan login) */
(() => {
  'use strict';

  const TODAY = new Date(); TODAY.setHours(0, 0, 0, 0);
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  const STATUS = {
    late: { label: 'Terlambat', cls: 'late', color: '#d33a32' },
    proc: { label: 'Dalam proses', cls: 'proc', color: '#2e8b57' },
    wait: { label: 'Menunggu verifikasi', cls: 'wait', color: '#e08a12' },
    done: { label: 'Selesai', cls: 'done', color: '#14532d' },
  };
  const PRI = { Tinggi: '#d33a32', Sedang: '#e08a12', Rendah: '#2f7fc1' };
  const BAR_COLORS = ['#14532d', '#e08a12', '#2a8a52', '#2f7fc1', '#8a5cc2', '#c2548a'];

  /* ---------- icons ---------- */
  const P = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    list: '<path d="M10 6h11M10 12h11M10 18h11M3 6l1.5 1.5L7 5M3 12l1.5 1.5L7 11M3 18l1.5 1.5L7 17"/>',
    sprout: '<path d="M7 20h10M12 20v-9"/><path d="M12 11c0-3-2-5-6-5 0 3 2 5 6 5zM12 13c0-3 2-5 6-5 0 3-2 5-6 5z"/>',
    bell: '<path d="M6 8a6 6 0 0112 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.9 1.9 0 003.4 0"/>',
    file: '<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0113 0M16 4.5a3.5 3.5 0 010 7M18 14.5a6.5 6.5 0 013.5 5.5"/>',
    cog: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 015.8 1c0 2-3 3-3 3M12 17h.01"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    cal: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    down: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
    up: '<path d="M12 21V9M7 14l5-5 5 5M5 3h14"/>',
    chat: '<path d="M21 12a8 8 0 01-11.6 7.1L3 21l1.9-5.4A8 8 0 1121 12z"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    alert: '<path d="M12 3l10 18H2zM12 10v5M12 18h.01"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    doc: '<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5"/>',
    chevd: '<path d="M6 9l6 6 6-6"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    clip: '<path d="M21 11.5l-8.6 8.6a5.5 5.5 0 01-7.8-7.8l8.6-8.6a3.7 3.7 0 015.2 5.2l-8.6 8.6a1.8 1.8 0 01-2.6-2.6l7.9-7.9"/>',
    chevl: '<path d="M15 6l-6 6 6 6"/>',
    link: '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',
  };
  const ic = (n, extra = '') => `<svg class="ic" viewBox="0 0 24 24" ${extra}>${P[n]}</svg>`;

  /* ---------- helpers ---------- */
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = s => { const d = parse(s); return `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()}`; };
  const diffDays = s => Math.round((parse(s) - TODAY) / 864e5);
  const addDays = n => { const d = new Date(TODAY); d.setDate(d.getDate() + n); return iso(d); };
  const initials = n => String(n || '?').split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const pct = (n, t) => t ? Math.round(n / t * 100) : 0;
  const toast = msg => { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 3000); };

  /* ---------- seed (contoh) ---------- */
  function seed() {
    const kebun = [
      { id: 'k1', nama: 'Kebun Suka Makmur', prov: 'Riau', divisi: 'Divisi Utara', pic: 'Budi Santoso', wa: '6281200000001' },
      { id: 'k2', nama: 'Kebun Harapan Jaya', prov: 'Riau', divisi: 'Divisi Timur', pic: 'Siti Rahmawati', wa: '6281200000002' },
      { id: 'k3', nama: 'Kebun Maju Bersama', prov: 'Jambi', divisi: 'Divisi Selatan', pic: 'Dewi Lestari', wa: '6281200000003' },
      { id: 'k4', nama: 'Kebun Tani Sejahtera', prov: 'Jambi', divisi: 'Divisi Barat', pic: 'Rudi Hartono', wa: '6281200000004' },
    ];
    const explicit = [
      ['Perbaikan saluran drainase blok C12', 'k1', 'Budi Santoso', 0, 'Tinggi', 'late', 'Infrastruktur'],
      ['Pembaruan log penggunaan pestisida', 'k2', 'Siti Rahmawati', 2, 'Sedang', 'wait', 'Kepatuhan'],
      ['Kelengkapan APD di gudang pupuk', 'k1', 'Agus Pranoto', 4, 'Sedang', 'proc', 'K3'],
      ['Rekonsiliasi stok pupuk semester II', 'k3', 'Dewi Lestari', 6, 'Sedang', 'proc', 'Inventory'],
      ['Papan informasi area sempadan sungai', 'k4', 'Rudi Hartono', -2, 'Rendah', 'done', 'Lingkungan'],
      ['Pemeriksaan berkala alat pemadam', 'k4', 'Rudi Hartono', 10, 'Sedang', 'proc', 'K3'],
    ];
    const more = [
      ['Pencatatan hasil panen harian', 'Operasional'], ['Perawatan jalan produksi blok B', 'Infrastruktur'],
      ['Verifikasi dokumen HGU', 'Kepatuhan'], ['Kalibrasi timbangan TBS', 'Operasional'],
      ['Penyimpanan bahan kimia terpisah', 'K3'], ['Pembaruan daftar hadir pekerja', 'SDM'],
      ['Pengelolaan limbah domestik', 'Lingkungan'], ['Perbaikan atap gudang alat', 'Infrastruktur'],
      ['Pelatihan K3 pekerja baru', 'SDM'], ['Pengecekan sistem pencatatan BBM', 'Inventory'],
      ['Kelengkapan P3K di afdeling', 'K3'], ['Dokumentasi pemupukan blok A', 'Operasional'],
      ['Pembersihan piringan pokok', 'Operasional'], ['Pemasangan rambu keselamatan', 'K3'],
      ['Penertiban kontrak pihak ketiga', 'Kepatuhan'], ['Pemeliharaan jembatan blok D', 'Infrastruktur'],
    ];
    const quota = { k1: 16, k2: 13, k3: 11, k4: 8 };
    const stQuota = { done: 23, proc: 13, wait: 5, late: 7 };
    explicit.forEach(e => { quota[e[1]]--; stQuota[e[5]]--; });
    const kPool = []; Object.entries(quota).forEach(([k, n]) => { for (let i = 0; i < n; i++) kPool.push(k); });
    const sPool = []; Object.entries(stQuota).forEach(([s, n]) => { for (let i = 0; i < n; i++) sPool.push(s); });
    const total = kPool.length;
    const mk = ([deskripsi, kebun, pic, off, prioritas, status, kategori]) => ({ deskripsi, kebun, pic, due: addDays(off), prioritas, status, kategori });
    const items = explicit.map(mk);
    const kById = Object.fromEntries(kebun.map(k => [k.id, k]));
    for (let i = 0; i < total; i++) {
      const k = kPool[(i * 5) % total], s = sPool[(i * 11 + 3) % total];
      const [desc, cat] = more[i % more.length];
      const off = s === 'late' ? -(1 + (i % 12)) : s === 'done' ? -(3 + (i % 20)) : 3 + ((i * 3) % 40);
      items.push(mk([desc + (i >= more.length ? ` (${Math.floor(i / more.length) + 1})` : ''), k, kById[k].pic, off, ['Tinggi', 'Sedang', 'Rendah'][i % 3], s, cat]));
    }
    items.forEach((it, i) => { it.id = `TMN-${TODAY.getFullYear()}-${String(i + 1).padStart(3, '0')}`; });
    const cp = curPeriod(), qN = cp.kuartal, yN = cp.tahun, qP = qN === 1 ? 3 : qN - 1, yP = qN === 1 ? yN - 1 : yN;
    const fu = [{ id: `f-${yP}-${qP}`, tahun: yP, kuartal: qP, ket: '' }, { id: `f-${yN}-${qN}`, tahun: yN, kuartal: qN, ket: '' }];
    items.forEach(it => { it.fu = it.status === 'done' ? fu[0].id : fu[1].id; });
    return { kebun, items, fu };
  }

  /* ---------- state & API ---------- */
  let db = { kebun: [], items: [], fu: [], files: [] };
  let me = null, ready = false, users = null, lastSync = new Date();
  let cfg = { lan: [], port: 3000 };
  const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };
  const ui = { page: 1, q: '', status: 'all', menu: null, closed: new Set(), side: lsGet('af.side') === '1' };
  const MAX_FILE = 50 * 1024 * 1024, FILE_EXT = ['.xlsx', '.xlsm', '.xls', '.csv', '.docx', '.doc'];
  const fileOf = i => (i && i.file && (db.files || []).find(f => f.id === i.file)) || null;
  const fmtSize = n => n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  const fileHref = f => `/f/${f.token}/${encodeURIComponent(f.name)}`;
  function baseUrl() {
    const v = (lsGet('af.base') || '').trim(); if (v) return v.replace(/\/+$/, '');
    const h = location.hostname;
    if (['localhost', '127.0.0.1', '[::1]', '::1'].includes(h) && cfg.lan && cfg.lan.length) return `http://${cfg.lan[0]}:${location.port || cfg.port}`;
    return location.origin;
  }
  const fileShare = f => baseUrl() + fileHref(f);
  async function copyText(t) {
    try { await navigator.clipboard.writeText(t); }
    catch (e) { const a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); } catch (x) { } a.remove(); }
    toast('Tautan disalin');
  }
  const nonePts = f => Math.max(0, f.total - f.done - (f.prog || 0));
  const segBar = (f, cls = '') => {
    const t = f.total || 1, d = f.done / t * 100, p = (f.prog || 0) / t * 100;
    return `<div class="seg ${cls}" role="img" aria-label="${f.done} selesai, ${f.prog || 0} sedang progres, ${nonePts(f)} tidak ada progres"><i class="s-d" style="width:${d}%"></i><i class="s-p" style="width:${p}%"></i></div>`;
  };
  function statsBlock(f) {
    if (f.mode === 'stat') {
      const p = pct(f.done, f.total), pr = f.prog || 0, no = nonePts(f);
      return `<div class="pts-box"><div class="pts-grid">
        <div><span>Total poin</span><b>${f.total}</b></div>
        <div><span>Selesai</span><b class="g">${f.done}</b></div>
        <div><span>Sedang progres</span><b class="a">${pr}</b></div>
        <div><span>Tidak ada progres</span><b class="o">${no}</b></div></div>
        ${segBar(f, 'lg')}
        <div class="seg-leg"><span><i class="s-d"></i>Selesai ${p}%</span><span><i class="s-p"></i>Sedang progres ${pct(pr, f.total)}%</span><span><i class="s-n"></i>Tidak ada progres ${pct(no, f.total)}%</span></div></div>`;
    }
    if (f.mode === 'nostat') return `<div class="pts-note">Total poin: <b>${f.total}</b>. Kolom <b>Status</b> tidak ditemukan di Excel, jadi poin selesai, sedang progres, dan tidak ada progres belum bisa dihitung. Tambahkan kolom &quot;Status&quot; (isi: Selesai / Dalam proses / Belum), lalu unggah ulang.</div>`;
    return `<div class="pts-note">Statistik poin hanya dibaca dari file Excel (.xlsx) atau CSV.</div>`;
  }
  function ptsLine(i) {
    const f = fileOf(i); if (!f) return '';
    const link = `<a class="fchip" href="${esc(fileHref(f))}" title="Unduh ${esc(f.name)}">${ic('clip', 'style="width:12px;height:12px"')}${esc(f.name)}</a>`;
    const p = f.mode === 'stat' ? `<span class="pts">${segBar(f)}${f.done}/${f.total} poin${f.prog ? ` · ${f.prog} progres` : ''}</span>` : f.mode === 'nostat' ? `<span class="pts">${f.total} poin</span>` : '';
    return `<span class="pts-row">${p}${link}</span>`;
  }
  // persentase selesai temuan = poin selesai / total poin di berkas temuan itu
  function itemPct(i) {
    const f = fileOf(i);
    if (f && f.mode === 'stat' && f.total) return { p: pct(f.done, f.total), tip: `${f.done} dari ${f.total} poin selesai (dari berkas Excel)` };
    if (i.status === 'done') return { p: 100, tip: 'Temuan ditandai selesai' };
    if (i.persen !== null && i.persen !== undefined && i.persen !== '') return { p: Math.max(0, Math.min(100, +i.persen)), tip: 'Progres diisi manual' };
    return null;
  }
  function stFull(i) {
    const x = itemPct(i);
    const chip = x ? `<span class="pc ${x.p >= 100 ? 'full' : x.p === 0 ? 'zero' : ''}" title="${esc(x.tip)}"><i style="--p:${x.p}"></i>${x.p}%</span>`
      : `<span class="pc na" title="Belum ada persentase: isi % progres di form temuan, atau lampirkan Excel dengan kolom Status">–</span>`;
    return `<span class="stwrap">${stCell(i.status)}${chip}</span>`;
  }
  const kebunOf = id => db.kebun.find(k => k.id === id) || { nama: '—', pic: '—', wa: '' };
  /* Triwulan: Q1 = Sep–Des, Q2 = Jan–Apr, Q3 = Mei–Agu. "tahun" = tahun mulai tahun buku (Q1 2026 = Sep–Des 2026; Q2/Q3 2026 = 2027). */
  const TW = [{ m: 'September–Desember', s: 'Sep–Des', add: 0 }, { m: 'Januari–April', s: 'Jan–Apr', add: 1 }, { m: 'Mei–Agustus', s: 'Mei–Agu', add: 1 }];
  const curPeriod = (d = TODAY) => { const m = d.getMonth(), y = d.getFullYear(); return m >= 8 ? { kuartal: 1, tahun: y } : m <= 3 ? { kuartal: 2, tahun: y - 1 } : { kuartal: 3, tahun: y - 1 }; };
  const fuName = f => 'Q' + f.kuartal + ' ' + f.tahun + '/' + (+f.tahun + 1);
  const fuRange = f => (TW[f.kuartal - 1] ? TW[f.kuartal - 1].m + ' ' + (+f.tahun + TW[f.kuartal - 1].add) : '');
  const fuSorted = () => db.fu.slice().sort((a, b) => b.tahun - a.tahun || b.kuartal - a.kuartal);
  const fuOf = id => db.fu.find(f => f.id === id);
  const fuLabel = id => { const f = fuOf(id); return f ? fuName(f) : ''; };
  const visItems = () => ui.fu === 'all' ? db.items : db.items.filter(i => i.fu === ui.fu);
  const setFu = v => { ui.fu = v; ui.page = 1; try { localStorage.setItem('af.fu', v); } catch (e) { } };
  function ensureFu() {
    if (ui.fu === undefined) { let v = null; try { v = localStorage.getItem('af.fu'); } catch (e) { } ui.fu = v; }
    if (ui.fu !== 'all' && !fuOf(ui.fu)) ui.fu = db.fu.length ? fuSorted()[0].id : 'all';
  }
  const periodTitle = () => ui.fu === 'all' || !fuOf(ui.fu) ? 'seluruh Follow Up Audit' : '<b>Follow Up Audit ' + fuName(fuOf(ui.fu)) + '</b>';

  async function api(method, url, body) {
    const r = await fetch(url, { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && url !== '/api/login') { me = null; if (ready) render(); throw new Error(j.error || 'Sesi berakhir, silakan masuk lagi'); }
    if (!r.ok) throw new Error(j.error || 'Terjadi kesalahan');
    return j;
  }
  async function refresh() {
    const d = await api('GET', '/api/data'); const s = JSON.stringify(d);
    lastSync = new Date();
    if (s !== refresh.last) { refresh.last = s; db = { files: [], ...d }; ensureFu(); return true; }
    return false;
  }
  async function poll() {
    if (!me || document.hidden || $('#modal-root').firstChild || ui.menu) return;
    try { if (await refresh()) render(); } catch (e) { /* abaikan */ }
  }

  /* ---------- pages ---------- */
  const PAGES = {
    ringkasan: { title: 'Ringkasan', icon: 'grid' },
    followup: { title: 'Follow Up Audit', icon: 'layers' },
    temuan: { title: 'Temuan audit', icon: 'list' },
    kebun: { title: 'Kebun & PIC', icon: 'sprout' },
    pengingat: { title: 'Pengingat', icon: 'bell' },
    impor: { title: 'Impor & ekspor', icon: 'file' },
    pengguna: { title: 'Pengguna', icon: 'users', admin: true },
  };
  const route = () => { const h = location.hash.replace('#/', ''); const p = PAGES[h]; return p && (!p.admin || (me && me.role === 'admin')) ? h : 'ringkasan'; };

  function shell(key, body) {
    const open = visItems().filter(i => i.status !== 'done').length;
    const fuSel = `<label class="fu-pick" title="Pilih Follow Up Audit">${ic('cal')}<select id="fu-sel"><option value="all" ${ui.fu === 'all' ? 'selected' : ''}>Semua periode</option>${fuSorted().map(f => `<option value="${esc(f.id)}" ${ui.fu === f.id ? 'selected' : ''}>Follow Up Audit ${fuName(f)}</option>`).join('')}</select></label>`;
    const nav = Object.entries(PAGES).filter(([, p]) => !p.admin || me.role === 'admin').map(([k, p]) =>
      `<a href="#/${k}" class="${k === key ? 'active' : ''}" title="${p.title}">${ic(p.icon)}<span class="lbl">${p.title}</span>${k === 'temuan' ? `<span class="badge">${open}</span>` : ''}</a>`).join('');
    return `<div class="layout${ui.side ? ' collapsed' : ''}"><div class="scrim" data-act="menu-close"></div>
      <aside class="sidebar">
        <button class="side-toggle" data-act="side-toggle" aria-label="${ui.side ? 'Perbesar menu' : 'Perkecil menu'}" title="${ui.side ? 'Perbesar menu' : 'Perkecil menu'}">${ic('chevl')}</button>
        <div class="brand"><div class="logo">AF</div><div class="brand-t"><b>Audit Follow Up</b><span>Julong Grup Indonesia</span></div></div>
        <div class="menu-label">MENU UTAMA</div>
        <nav class="nav">${nav}</nav>
        <div class="spacer"></div>
        <div class="preview"><b><i style="background:#2a8a52"></i>Terhubung ke database</b>Data tersimpan di server dan dibagikan ke semua pengguna.</div>
        <button class="side-btn" data-act="settings" title="Pengaturan">${ic('cog')}<span class="lbl">Pengaturan</span></button>
        <button class="side-btn" data-act="help" title="Pusat bantuan">${ic('help')}<span class="lbl">Pusat bantuan</span></button>
      </aside>
      <div class="main">
        <header class="topbar">
          <div class="tb-left"><button class="burger" data-act="menu" aria-label="Buka menu">${ic('menu')}</button><div class="crumb"><small>Operasional / ${PAGES[key].title}</small><h1>${PAGES[key].title}</h1></div></div>
          <div class="top-right">
            ${fuSel}
            <button class="bell" data-go="pengingat" title="Pengingat">${ic('bell')}<i></i></button>
            <div class="user" data-act="settings" title="Pengaturan akun"><div class="avatar">${esc(initials(me.name))}</div><div><b>${esc(me.name)}</b><span>${me.role === 'admin' ? 'Admin' : 'Auditor'}</span></div></div>
          </div>
        </header>
        <main class="content">${body}</main>
      </div></div>`;
  }

  const stat = (l, v, u, sub, icon, cls) => `<div class="card stat"><div class="lbl">${l}</div><div class="ico ${cls}">${ic(icon)}</div><div class="num">${v}<small>${u}</small></div>${sub}</div>`;
  const dueCell = i => { const d = diffDays(i.due); return `<span>${fmt(i.due)}<span class="id">${i.status === 'done' ? 'Selesai' : d < 0 ? `${-d} hari lalu` : d === 0 ? 'Hari ini' : `${d} hari lagi`}</span></span>`; };
  const priCell = p => `<span class="pri"><i style="background:${PRI[p]}"></i>${p}</span>`;
  const stCell = s => `<span class="st ${STATUS[s].cls}">${STATUS[s].label}</span>`;
  function rowAttn(i) {
    return `<tr><td class="c-main">${esc(i.deskripsi)}<span class="id">${ui.fu === 'all' && fuLabel(i.fu) ? esc(fuLabel(i.fu)) + ' · ' : ''}${esc(i.id)} · ${esc(i.kategori || '')}</span>${ptsLine(i)}</td><td data-label="Kebun">${esc(kebunOf(i.kebun).nama)}</td><td data-label="Tim Auditor">${i.auditor ? esc(i.auditor) : '<span class="muted-dash">—</span>'}</td><td data-label="PIC">${esc(i.pic)}</td><td data-label="Jatuh tempo">${dueCell(i)}</td><td data-label="Prioritas">${priCell(i.prioritas)}</td><td data-label="Status">${stFull(i)}</td>${actionCell(i)}</tr>`;
  }
  function rowMenu(i) {
    return `<div class="rel"><button class="dots" data-menu="${esc(i.id)}">•••</button>${ui.menu === i.id ? `<div class="menu-pop">
      <button data-row="wa" data-id="${esc(i.id)}">Hubungi PIC${i.file ? ' + berkas' : ''}</button>
      ${i.file ? `<button data-row="file" data-id="${esc(i.id)}">Berkas &amp; poin</button>` : ''}
      ${i.status !== 'done' ? `<button data-row="done" data-id="${esc(i.id)}">Tandai selesai</button>` : `<button data-row="reopen" data-id="${esc(i.id)}">Buka kembali</button>`}
      <button data-row="edit" data-id="${esc(i.id)}">Ubah</button>
      <button class="danger" data-row="del" data-id="${esc(i.id)}">Hapus</button></div>` : ''}</div>`;
  }
  function actionCell(i) { return `<td class="c-act" style="width:50px">${rowMenu(i)}</td>`; }

  /* ---------- Follow Up Audit: Periode → Kebun → Bagian → Temuan ---------- */
  const BAGIAN_DEFAULT = ['Inventory', 'Aset Tetap', 'Kas & Bank', 'Pembelian', 'Penjualan', 'SDM & Payroll', 'Kepatuhan', 'K3', 'Lingkungan', 'Infrastruktur', 'Operasional'];
  const bagianList = () => [...new Set(BAGIAN_DEFAULT.concat(db.items.map(i => i.kategori).filter(Boolean)))];
  const treeRow = i => `<div class="tr-row"><div class="tr-d"><b>${esc(i.deskripsi)}</b><span class="id">${esc(i.id)}${i.pic ? ' · PIC ' + esc(i.pic) : ''}${i.auditor ? ' · Auditor ' + esc(i.auditor) : ''}</span>${ptsLine(i)}</div><div class="tr-due">${dueCell(i)}</div><div>${priCell(i.prioritas)}</div><div>${stFull(i)}</div>${rowMenu(i)}</div>`;
  const addBtn = (f, k, b, label) => `<button class="btn sm" data-act="add-in" data-fu="${esc(f)}" data-k="${esc(k)}" data-b="${esc(b)}">${ic('plus', 'style="width:13px;height:13px"')}${label}</button>`;

  function pageFollowup() {
    const fus = fuSorted();
    const cards = fus.map(f => {
      const its = db.items.filter(i => i.fu === f.id), n = its.length, d = its.filter(i => i.status === 'done').length, late = its.filter(i => i.status === 'late').length;
      const pf = its.map(fileOf).filter(x => x && x.mode === 'stat'), pt = pf.reduce((a, x) => a + x.total, 0), pd = pf.reduce((a, x) => a + x.done, 0), pp = pf.reduce((a, x) => a + (x.prog || 0), 0);
      return `<div class="card fu-card ${ui.fu === f.id ? 'active' : ''}" data-act="fu-select" data-id="${esc(f.id)}">
        <div class="fu-top"><span class="fu-q">Q${f.kuartal}</span><span class="fu-y">${f.tahun}/${+f.tahun + 1}</span>${late ? `<span class="st late">${late} terlambat</span>` : ''}</div>
        <h3>Follow Up Audit ${fuName(f)}</h3><div class="loc">${esc(fuRange(f))}${f.ket ? ' · ' + esc(f.ket) : ''}</div>
        <div class="bar" style="margin:12px 0 6px"><i style="width:${pct(d, n)}%;background:var(--green-700)"></i></div>
        <div class="fu-meta">${n} temuan · ${d} selesai (${pct(d, n)}%)</div>${pt ? `<div class="fu-meta" style="margin-top:2px">Poin Excel: ${pd}/${pt} selesai (${pct(pd, pt)}%)${pp ? ` · ${pp} sedang progres` : ''}</div>` : ''}
        <div class="fu-btns"><button class="btn sm" data-act="fu-edit" data-id="${esc(f.id)}">Ubah</button>${me.role === 'admin' ? `<button class="btn sm" style="color:var(--red)" data-act="fu-del" data-id="${esc(f.id)}">Hapus</button>` : ''}</div></div>`;
    }).join('');

    const shown = ui.fu === 'all' ? fus : fus.filter(f => f.id === ui.fu);
    const tree = shown.map(f => {
      const its = db.items.filter(i => i.fu === f.id), openN = its.filter(i => i.status !== 'done').length;
      const kb = db.kebun.map(k => {
        const ki = its.filter(i => i.kebun === k.id), ko = ki.filter(i => i.status !== 'done').length, groups = {};
        ki.forEach(i => { const g = i.kategori || 'Tanpa bagian'; (groups[g] = groups[g] || []).push(i); });
        const gh = Object.keys(groups).sort((a, b) => a.localeCompare(b)).map(g =>
          `<div class="tr-b"><div class="tr-bh"><span>${esc(g)}</span><em>${groups[g].length}</em>${addBtn(f.id, k.id, g === 'Tanpa bagian' ? '' : g, '')}</div>${groups[g].sort((a, b) => a.due.localeCompare(b.due)).map(treeRow).join('')}</div>`).join('');
        const key = 'k:' + f.id + ':' + k.id;
        return `<details class="tr-k" data-key="${esc(key)}" ${ui.closed.has(key) ? '' : 'open'}><summary><span class="tr-kn">${ic('sprout')}<b>${esc(k.nama)}</b><small>${esc(k.prov || '')}${k.divisi ? ' · ' + esc(k.divisi) : ''}</small></span><span class="tr-meta">${ki.length} temuan · ${ko} belum selesai</span>${addBtn(f.id, k.id, '', 'Temuan')}</summary>${gh || '<div class="tr-empty">Belum ada temuan untuk kebun ini.</div>'}</details>`;
      }).join('');
      const key = 'f:' + f.id;
      return `<details class="tr-f card" data-key="${esc(key)}" ${ui.closed.has(key) ? '' : 'open'}><summary><span class="tr-fn"><span class="fu-q sm">Q${f.kuartal}</span><b>Follow Up Audit ${fuName(f)}</b></span><span class="tr-meta">${its.length} temuan · ${openN} belum selesai</span>${addBtn(f.id, '', '', 'Temuan')}</summary><div class="tr-body">${kb || '<div class="tr-empty">Belum ada kebun. Tambahkan di menu Kebun &amp; PIC.</div>'}</div></details>`;
    }).join('');

    return `<div class="lead"><div>Kelompokkan tindak lanjut per triwulan. Di dalam tiap Follow Up Audit, temuan dikelompokkan per <b>kebun</b>, lalu per <b>bagian</b> (Inventory, K3, dan lainnya).</div><button class="btn primary" data-act="add-fu">${ic('plus')}Tambah Follow Up Audit</button></div>
      ${fus.length ? `<div class="fu-grid">${cards}</div><div class="fu-sec"><h3>Rincian ${ui.fu === 'all' ? 'seluruh periode' : 'Follow Up Audit ' + fuName(fuOf(ui.fu))}</h3>${tree}</div>`
        : `<div class="hint"><b>Belum ada Follow Up Audit.</b> Klik <b>Tambah Follow Up Audit</b> untuk membuat yang pertama, misalnya ${fuName(curPeriod())}.</div>`}`;
  }

  function fuModal(f) {
    const e = f || { ...curPeriod(), ket: '' };
    modal(`<h2>${f ? 'Ubah' : 'Tambah'} Follow Up Audit</h2>
      <div class="row2"><div class="field"><label>Triwulan</label><select name="kuartal">${[1, 2, 3].map(q => `<option value="${q}" ${q === +e.kuartal ? 'selected' : ''}>Q${q} (${TW[q - 1].s})</option>`).join('')}</select></div>
        <div class="field"><label>Tahun buku (mulai September)</label><input type="number" name="tahun" required min="2000" max="2100" value="${esc(e.tahun)}"></div></div>
      <div class="fu-hint" id="fu-hint"></div>
      <div class="field"><label>Keterangan (opsional)</label><input name="ket" maxlength="200" value="${esc(e.ket || '')}" placeholder="mis. Audit internal semester 2"></div>
      <div class="actions"><button type="button" class="btn" data-close>Batal</button><button class="btn primary">Simpan</button></div>`,
      async (d, close) => {
        const r = f ? await api('PUT', `/api/fu/${encodeURIComponent(f.id)}`, d) : await api('POST', '/api/fu', d);
        await refresh(); if (!f) setFu(r.id); close(); toast(f ? 'Follow Up Audit diperbarui' : 'Follow Up Audit dibuat'); render();
      });
    const root = $('#modal-root'), q = $('select[name=kuartal]', root), t = $('input[name=tahun]', root), h = $('#fu-hint', root);
    const upd = () => { const o = { kuartal: +q.value, tahun: +t.value }; h.textContent = o.tahun ? `Q${o.kuartal} ${o.tahun}/${o.tahun + 1} · ${fuRange(o)}` : ''; };
    q.onchange = upd; t.oninput = upd; upd();
  }

  function pageRingkasan() {
    const it = visItems(), n = it.length;
    const c = s => it.filter(i => i.status === s).length;
    const done = c('done'), proc = c('proc'), wait = c('wait'), late = c('late');
    const perlu = it.filter(i => i.status !== 'done' && diffDays(i.due) <= 14).length;
    const urgent = it.filter(i => i.status !== 'done' && i.prioritas === 'Tinggi').length;
    const soon = it.filter(i => i.status !== 'done' && diffDays(i.due) >= 0 && diffDays(i.due) <= 7).length;
    const R = 66, C = 2 * Math.PI * R; let off = 0;
    const segs = [['done', done], ['proc', proc], ['wait', wait], ['late', late]].map(([s, v]) => {
      const len = n ? v / n * C : 0;
      const el = `<circle cx="85" cy="85" r="${R}" fill="none" stroke="${STATUS[s].color}" stroke-width="22" stroke-dasharray="${Math.max(len - 1.5, 0)} ${C}" stroke-dashoffset="${-off}"/>`;
      off += len; return el;
    }).join('');
    const legend = [['done', done], ['proc', proc], ['wait', wait], ['late', late]].map(([s, v]) =>
      `<div class="row"><span class="dot" style="background:${STATUS[s].color}"></span><span>${STATUS[s].label}</span><span class="val">${v} <small>(${pct(v, n)}%)</small></span>
       <div class="bar"><i style="width:${pct(v, n)}%;background:${STATUS[s].color}"></i></div></div>`).join('');
    const rk = db.kebun.map(k => ({ k, n: it.filter(i => i.kebun === k.id).length })).sort((a, b) => b.n - a.n).slice(0, 5);
    const mx = Math.max(1, ...rk.map(r => r.n));
    const rank = rk.map((r, i) => `<div class="r"><span class="n">0${i + 1}</span><b>${esc(r.k.nama)}</b><span class="v">${r.n} temuan</span>
      <div class="bar"><i style="width:${r.n / mx * 100}%;background:${BAR_COLORS[i % 6]}"></i></div></div>`).join('') || '<div class="empty" style="padding:16px">Belum ada kebun.</div>';
    const attn = it.filter(i => i.status === 'late' || i.status === 'wait').sort((a, b) => a.due.localeCompare(b.due)).slice(0, 5);
    const hr = new Date().getHours(); const sapa = hr < 11 ? 'pagi' : hr < 15 ? 'siang' : hr < 18 ? 'sore' : 'malam';
    const hhmm = `${String(lastSync.getHours()).padStart(2, '0')}.${String(lastSync.getMinutes()).padStart(2, '0')}`;
    const hint = !db.fu.length ? `<div class="hint"><b>Belum ada Follow Up Audit.</b> Buat dulu di menu <a href="#/followup" style="color:var(--green-700);font-weight:600">Follow Up Audit</a> (mis. ${fuName(curPeriod())}), lalu tambahkan kebun dan temuan.</div>` : !db.kebun.length ? `<div class="hint"><b>Belum ada data.</b> Mulai dengan <a href="#/kebun" style="color:var(--green-700);font-weight:600">menambah kebun</a>, lalu temuan. ${me.role === 'admin' ? 'Atau muat data contoh lewat <b>Pengaturan</b>.' : ''}</div>` : '';

    return `<div class="lead"><div>Selamat ${sapa}, ${esc(me.name.split(' ')[0])}. Berikut perkembangan tindak lanjut ${periodTitle()}.<br><small style="color:var(--muted)">Terakhir diperbarui ${fmt(iso(lastSync))}, ${hhmm} WIB</small></div>
        <button class="btn primary" data-act="add-finding">${ic('plus')}Tambah temuan</button></div>${hint}
      <div class="grid-4">
        ${stat('Total temuan aktif', n, '', `<span class="sub link">${db.kebun.length} kebun terdata</span>`, 'doc', '')}
        ${stat('Perlu ditindaklanjuti', perlu, '', `<span class="sub">${urgent} prioritas tinggi</span>`, 'clock', 'amber')}
        ${stat('Terlambat', late, '', `<span class="sub">Melebihi batas waktu</span>`, 'alert', 'red')}
        ${stat('Selesai', done, '', `<span class="sub">${soon} jatuh tempo 7 hari ke depan</span>`, 'shield', 'grn')}
      </div>
      <div class="two-col">
        <div class="card panel"><h3>Status tindak lanjut</h3><div class="desc">Distribusi seluruh temuan audit</div>
          <div class="donut-wrap"><div class="donut"><svg width="170" height="170" viewBox="0 0 170 170"><circle cx="85" cy="85" r="${R}" fill="none" stroke="#eef0ea" stroke-width="22"/>${segs}</svg>
            <div class="center"><b>${n}</b><span>total temuan</span></div></div>
            <div class="legend">${legend}</div></div></div>
        <div class="card panel"><div class="panel-head"><div><h3>Kebun dengan temuan terbanyak</h3><div class="desc">Temuan aktif per kebun</div></div><a href="#/kebun">Lihat semua</a></div>
          <div class="rank">${rank}</div></div>
      </div>
      <div class="card scroll"><div class="panel" style="padding-bottom:8px"><div class="panel-head"><div><h3>Perlu perhatian</h3><div class="desc">Temuan yang sudah melewati batas waktu atau menunggu verifikasi</div></div><a href="#/temuan">Lihat semua temuan</a></div></div>
        <table class="rt"><thead><tr><th>Temuan / ID</th><th>Kebun</th><th>Tim Auditor</th><th>PIC</th><th>Jatuh tempo</th><th>Prioritas</th><th>Status</th><th></th></tr></thead><tbody>${attn.map(rowAttn).join('') || `<tr><td colspan="8" class="empty">Tidak ada temuan yang perlu perhatian</td></tr>`}</tbody></table>
        <div class="tbl-foot"><span>${attn.length} temuan memerlukan perhatian</span></div></div>`;
  }

  function filtered() {
    const q = ui.q.toLowerCase();
    return visItems().filter(i => (ui.status === 'all' || i.status === ui.status) &&
      (!q || [i.deskripsi, i.id, i.pic, i.auditor, kebunOf(i.kebun).nama].join(' ').toLowerCase().includes(q)))
      .sort((a, b) => a.due.localeCompare(b.due));
  }
  const PER = 6;
  function pageTemuan() {
    const list = filtered(), pages = Math.max(1, Math.ceil(list.length / PER));
    ui.page = Math.min(ui.page, pages);
    const slice = list.slice((ui.page - 1) * PER, ui.page * PER);
    const from = list.length ? (ui.page - 1) * PER + 1 : 0;
    const pager = [`<button data-pg="${ui.page - 1}" ${ui.page === 1 ? 'disabled' : ''}>‹</button>`,
      ...Array.from({ length: pages }, (_, k) => `<button data-pg="${k + 1}" class="${k + 1 === ui.page ? 'on' : ''}">${k + 1}</button>`),
      `<button data-pg="${ui.page + 1}" ${ui.page === pages ? 'disabled' : ''}>›</button>`].join('');
    const opts = [['all', 'Semua status'], ...Object.entries(STATUS).map(([k, v]) => [k, v.label])].map(([k, l]) => `<option value="${k}" ${ui.status === k ? 'selected' : ''}>${l}</option>`).join('');
    return `<div class="lead"><div>Kelola temuan audit dan pantau progres tindak lanjut setiap kebun.</div><button class="btn primary" data-act="add-finding">${ic('plus')}Tambah temuan</button></div>
      <div class="card scroll"><div class="toolbar"><label class="search">${ic('search')}<input id="q" placeholder="Cari temuan, kebun, auditor, atau PIC..." value="${esc(ui.q)}"></label>
        <div style="display:flex;gap:10px"><select class="sel" id="fs">${opts}</select><button class="btn" data-act="export">${ic('down')}Ekspor</button></div></div>
        <table class="rt"><thead><tr><th>Temuan / ID</th><th>Kebun</th><th>Tim Auditor</th><th>PIC</th><th>Jatuh tempo</th><th>Prioritas</th><th>Status</th><th></th></tr></thead>
        <tbody>${slice.map(rowAttn).join('') || `<tr><td colspan="8" class="empty">Tidak ada temuan yang cocok.</td></tr>`}</tbody></table>
        <div class="tbl-foot"><span>Menampilkan ${from}–${from ? from + slice.length - 1 : 0} dari ${list.length} temuan</span><div class="pager">${pager}</div></div></div>`;
  }

  function pageKebun() {
    const cards = db.kebun.map(k => {
      const its = visItems().filter(i => i.kebun === k.id);
      const open = its.filter(i => i.status !== 'done').length;
      return `<div class="card kebun"><div class="top"><div class="ico">${ic('sprout')}</div>
        <div class="rel"><button class="dots" data-menu="k-${esc(k.id)}">•••</button>${ui.menu === 'k-' + k.id ? `<div class="menu-pop"><button data-krow="edit" data-id="${esc(k.id)}">Ubah kebun</button><button class="danger" data-krow="del" data-id="${esc(k.id)}">Hapus kebun</button></div>` : ''}</div></div>
        <h3>${esc(k.nama)}</h3><div class="loc">${esc(k.prov)} · ${esc(k.divisi)}</div>
        <div class="mini"><div><b>${its.length}</b><span>Total temuan</span></div><div><b style="color:#b0561d">${open}</b><span>Belum selesai</span></div></div>
        <div class="pic"><div class="avatar">${esc(initials(k.pic))}</div><div class="who"><b>${esc(k.pic)}</b><span>Penanggung jawab</span></div>
        <button class="btn sm" data-wa-k="${esc(k.id)}">${ic('chat', 'style="width:14px;height:14px"')}WhatsApp</button></div></div>`;
    }).join('');
    return `<div class="lead"><div>Informasi kontak penanggung jawab dan ringkasan temuan per kebun.</div><button class="btn" data-act="add-kebun">${ic('plus')}Tambah kebun</button></div>
      <div class="kebun-grid">${cards || '<div class="card empty">Belum ada kebun.</div>'}</div>`;
  }

  function pageReminder() {
    const open = visItems().filter(i => i.status !== 'done').sort((a, b) => a.due.localeCompare(b.due));
    const week = open.filter(i => diffDays(i.due) <= 7).length;
    const pics = new Set(open.filter(i => diffDays(i.due) <= 7).map(i => i.pic)).size;
    const rows = open.slice(0, 8).map(i => {
      const d = diffDays(i.due), late = d < 0;
      return `<div class="rem"><div class="ci ${late ? 'red' : ''}">${ic('chat')}</div>
        <div class="t"><b>${esc(i.deskripsi)}</b><span>${esc(i.pic)} · ${esc(kebunOf(i.kebun).nama)} · <em>Jatuh tempo ${fmt(i.due)}</em></span></div>
        <span class="when ${late ? 'red' : ''}">${late ? 'Terlambat' : d === 0 ? 'Hari ini' : `H-${d}`}</span>
        <button class="btn sm" data-row="wa" data-id="${esc(i.id)}">Hubungi PIC</button></div>`;
    }).join('');
    return `<div class="lead"><div>Pantau jadwal pengingat tindak lanjut untuk para PIC kebun.</div></div>
      <div class="alert">${ic('bell', 'style="width:20px;height:20px"')}<div><b>Pengingat WhatsApp otomatis belum aktif</b><span>Pengiriman otomatis memerlukan layanan WhatsApp Business API. Untuk saat ini, hubungi PIC secara manual lewat tombol "Hubungi PIC" (pesan sudah terisi).</span></div></div>
      <div class="grid-3">
        ${stat('Jatuh tempo ≤ 7 hari', week, '', '<span class="sub">termasuk yang terlambat</span>', 'cal', '')}
        ${stat('Belum selesai', open.length, '', `<span class="sub">${pics} PIC perlu diingatkan</span>`, 'clock', 'amber')}
        ${stat('Selesai', visItems().length - open.length, '', '<span class="sub">dari seluruh temuan</span>', 'check', '')}
      </div>
      <div class="card"><div class="panel" style="padding-bottom:14px"><h3>Jadwal pengingat berikutnya</h3><div class="desc" style="margin:0">Daftar berdasarkan tenggat tindak lanjut</div></div>${rows || '<div class="empty">Tidak ada pengingat.</div>'}</div>`;
  }

  function pageImpor() {
    return `<div class="lead"><div>Pindahkan data temuan audit menggunakan file spreadsheet.</div></div>
      <div class="ie-grid">
        <div class="card ie"><div class="ico" style="background:var(--green-100);color:var(--green-800)">${ic('down')}</div><h3>Ekspor data temuan</h3>
          <p>Unduh daftar temuan beserta status, tenggat, kebun, dan informasi PIC dalam format CSV yang dapat dibuka di Excel.</p>
          <div class="note">${ic('doc')}CSV · UTF-8 · kompatibel dengan Excel</div>
          <button class="btn primary" data-act="export">${ic('down')}Unduh data</button></div>
        <div class="card ie"><div class="ico" style="background:var(--amber-bg);color:var(--orange)">${ic('up')}</div><h3>Impor dari spreadsheet</h3>
          <p>Pilih file Excel (.xlsx) atau CSV berisi data temuan. Anda akan melihat pratinjau sebelum data disimpan; baris yang sudah ada dilewati. Kolom <b>Periode</b> (mis. Q1 2026/2027) menentukan Follow Up Audit; jika kosong dipakai periode yang sedang dipilih.</p>
          <button type="button" class="btn sm" data-act="template" style="margin-bottom:12px">${ic('down', 'style="width:14px;height:14px"')}Unduh template</button>
          <label class="drop" id="drop"><input type="file" id="file" accept=".xlsx,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" hidden>${ic('up', 'style="width:20px;height:20px"')}<b>Pilih file untuk diimpor</b><small>Excel (.xlsx) atau CSV, hingga 10 MB · seret &amp; lepas juga bisa</small></label></div>
      </div>
      <div class="card ie" style="padding:18px 22px"><b>Kolom yang disertakan dalam ekspor</b><div class="tags">${COLS.map(c => `<span>${c}</span>`).join('')}</div></div>`;
  }

  function pagePengguna() {
    if (!users) return `<div class="card empty">Memuat pengguna…</div>`;
    const rows = users.map(u => `<tr><td class="c-main"><b>${esc(u.name)}</b><span class="id">@${esc(u.username)}</span></td>
      <td data-label="Peran"><span class="role ${u.role}">${u.role === 'admin' ? 'Admin' : 'Pengguna'}</span></td>
      <td class="c-btns" style="text-align:right;white-space:nowrap"><button class="btn sm" data-urow="pw" data-id="${u.id}">Atur kata sandi</button>
      ${u.id !== me.id ? ` <button class="btn sm" style="color:var(--red)" data-urow="del" data-id="${u.id}">Hapus</button>` : ''}</td></tr>`).join('');
    return `<div class="lead"><div>Kelola akun yang dapat masuk ke aplikasi. Semua pengguna dapat melihat dan mengubah data temuan; hanya admin yang mengelola akun.</div><button class="btn primary" data-act="add-user">${ic('plus')}Tambah pengguna</button></div>
      <div class="card scroll"><table class="rt"><thead><tr><th>Pengguna</th><th>Peran</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }

  /* ---------- CSV ---------- */
  const COLS = ['ID temuan', 'Periode', 'Deskripsi', 'Kebun', 'Tim Auditor', 'Bagian', 'PIC', 'Nomor WhatsApp', 'Jatuh tempo', 'Status', 'Prioritas', 'Persentase'];
  function exportCSV() {
    const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const lines = [COLS.map(q).join(',')];
    db.items.forEach(i => { const k = kebunOf(i.kebun); lines.push([i.id, fuLabel(i.fu), i.deskripsi, k.nama, i.auditor || '', i.kategori || '', i.pic, k.wa, i.due, STATUS[i.status].label, i.prioritas, (itemPct(i) || {}).p ?? ''].map(q).join(',')); });
    const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `temuan-audit-${iso(TODAY)}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000); toast('File CSV diunduh');
  }
  function parseCSV(t) {
    const rows = []; let r = [], f = '', q = false;
    t = t.replace(/^﻿/, '');
    for (let i = 0; i < t.length; i++) {
      const c = t[i];
      if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
      else if (c === '"') q = true;
      else if (c === ',' || c === ';') { r.push(f); f = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; r.push(f); rows.push(r); r = []; f = ''; }
      else f += c;
    }
    if (f || r.length) { r.push(f); rows.push(r); }
    return rows.filter(x => x.some(v => v.trim()));
  }
  /* ---------- impor (Excel .xlsx / CSV) ---------- */
  const ALIAS = {
    'ID temuan': ['id temuan', 'id'],
    'Periode': ['periode', 'follow up', 'follow up audit', 'triwulan', 'kuartal', 'quartal', 'quarter'],
    'Deskripsi': ['deskripsi', 'temuan', 'uraian', 'uraian temuan', 'deskripsi temuan'],
    'Kebun': ['kebun', 'nama kebun', 'unit'],
    'Tim Auditor': ['tim auditor', 'auditor', 'tim audit'],
    'Persentase': ['persentase', '% progres', 'persen', 'progres', 'progress'],
    'Bagian': ['bagian', 'kategori'],
    'PIC': ['pic', 'penanggung jawab'],
    'Nomor WhatsApp': ['nomor whatsapp', 'whatsapp', 'no whatsapp', 'no. whatsapp', 'nomor wa', 'no wa', 'no. wa', 'wa'],
    'Jatuh tempo': ['jatuh tempo', 'tanggal jatuh tempo', 'tenggat', 'due', 'due date', 'deadline'],
    'Status': ['status'],
    'Prioritas': ['prioritas', 'priority'],
  };
  const ST_ALIAS = { done: ['selesai', 'done', 'closed', 'tuntas', 'completed', 'complete'], late: ['terlambat', 'overdue', 'late', 'lewat'], wait: ['menunggu verifikasi', 'verifikasi', 'menunggu', 'waiting'], proc: ['dalam proses', 'proses', 'open', 'in progress', 'berjalan', 'baru'] };
  const PRI_ALIAS = { Tinggi: ['tinggi', 'high', 'urgent'], Sedang: ['sedang', 'medium', 'normal'], Rendah: ['rendah', 'low'] };
  const MONTHS = { jan: 0, januari: 0, january: 0, feb: 1, februari: 1, february: 1, mar: 2, maret: 2, march: 2, apr: 3, april: 3, mei: 4, may: 4, jun: 5, juni: 5, june: 5, jul: 6, juli: 6, july: 6, agu: 7, agt: 7, agustus: 7, aug: 7, august: 7, sep: 8, sept: 8, september: 8, okt: 9, oktober: 9, oct: 9, october: 9, nov: 10, november: 10, des: 11, desember: 11, dec: 11, december: 11 };
  const chkDate = (y, mo, d) => { const dt = new Date(y, mo, d); return dt.getFullYear() === y && dt.getMonth() === mo && dt.getDate() === d ? iso(dt) : null; };
  function normDate(v) {
    v = String(v ?? '').trim(); if (!v) return null;
    let m = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/); if (m) return chkDate(+m[1], +m[2] - 1, +m[3]);
    m = v.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})$/); if (m) return chkDate(+m[3] < 100 ? 2000 + +m[3] : +m[3], +m[2] - 1, +m[1]);
    m = v.match(/^(\d{1,2})\s+([A-Za-z]+)\.?\s+(\d{4})$/); if (m && MONTHS[m[2].toLowerCase()] !== undefined) return chkDate(+m[3], MONTHS[m[2].toLowerCase()], +m[1]);
    return null;
  }
  function parsePeriode(v) {
    v = String(v ?? '').trim();
    const RM = { i: 1, ii: 2, iii: 3, iv: 4 };
    const W = '(?:q|kuartal|quartal|quarter|triwulan|tw)', N = '([1-3]|iii|ii|i)(?![a-z0-9])';
    const num = x => RM[String(x).toLowerCase()] || +x;
    let m = v.match(new RegExp(W + '\\s*' + N + '\\D{0,12}?(\\d{4})', 'i')); if (m) return { kuartal: num(m[1]), tahun: +m[2] };
    m = v.match(new RegExp('(\\d{4})\\s*[/-]\\s*\\d{4}\\D{0,12}?' + W + '\\s*' + N, 'i')); if (m) return { kuartal: num(m[2]), tahun: +m[1] };
    m = v.match(new RegExp('(\\d{4})\\D{0,12}?' + W + '\\s*' + N, 'i')); if (m) return { kuartal: num(m[2]), tahun: +m[1] };
    return null;
  }
  const normWa = v => { let d = String(v ?? '').replace(/\D/g, ''); if (d.startsWith('0')) d = '62' + d.slice(1); return d; };
  const enumOf = (v, table) => { const x = String(v ?? '').trim().toLowerCase().replace(/\s+/g, ' '); for (const [k, list] of Object.entries(table)) if (list.includes(x)) return k; return null; };

  function buildImport(rows) {
    const norm = x => String(x ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
    const hi = rows.findIndex((r, i) => i < 10 && r.some(c => ALIAS['Deskripsi'].includes(norm(c))));
    if (hi < 0) return { error: 'Kolom "Deskripsi" tidak ditemukan. Gunakan baris judul seperti pada template.' };
    const ix = {};
    rows[hi].forEach((c, j) => { for (const [k, al] of Object.entries(ALIAS)) if (ix[k] === undefined && al.includes(norm(c))) ix[k] = j; });
    const kNew = [], fNew = [], iNew = [], warn = [];
    let dup = 0, empty = 0;
    const all = () => db.kebun.concat(kNew);
    const allFu = () => db.fu.concat(fNew);
    const defFu = ui.fu !== 'all' ? fuOf(ui.fu) : (fuSorted()[0] || null);
    const key = (d, k, due, f) => [d.toLowerCase(), k, due, f].join('|');
    const seen = new Set(db.items.map(i => key(i.deskripsi, i.kebun, i.due, i.fu)));
    rows.slice(hi + 1).forEach((r, n) => {
      const line = hi + 2 + n;
      const g = c => ix[c] === undefined ? '' : String(r[ix[c]] ?? '').trim();
      if (!g('Deskripsi')) { if (r.some(x => String(x ?? '').trim())) empty++; return; }
      let k = g('Kebun') ? all().find(x => x.nama.toLowerCase() === g('Kebun').toLowerCase()) : null;
      if (!k && g('Kebun')) { k = { id: 'k' + Date.now().toString(36) + kNew.length, nama: g('Kebun'), prov: '', divisi: '', pic: g('PIC'), wa: normWa(g('Nomor WhatsApp')) }; kNew.push(k); }
      if (!k) { k = all()[0]; if (!k) { warn.push('Baris ' + line + ': kebun kosong dan belum ada kebun, dilewati'); return; } warn.push('Baris ' + line + ': kebun kosong, dimasukkan ke "' + k.nama + '"'); }
      let due = normDate(g('Jatuh tempo'));
      if (!due) { warn.push('Baris ' + line + ': jatuh tempo ' + (g('Jatuh tempo') ? '"' + g('Jatuh tempo') + '" tidak dikenali' : 'kosong') + ', diisi 14 hari dari hari ini'); due = addDays(14); }
      let status = 'proc';
      if (g('Status')) { status = enumOf(g('Status'), ST_ALIAS); if (!status) { warn.push('Baris ' + line + ': status "' + g('Status') + '" tidak dikenali, diisi "Dalam proses"'); status = 'proc'; } }
      let prioritas = 'Sedang';
      if (g('Prioritas')) { prioritas = enumOf(g('Prioritas'), PRI_ALIAS); if (!prioritas) { warn.push('Baris ' + line + ': prioritas "' + g('Prioritas') + '" tidak dikenali, diisi "Sedang"'); prioritas = 'Sedang'; } }
      let f = null;
      if (g('Periode')) {
        const pq = parsePeriode(g('Periode'));
        if (pq) { f = allFu().find(x => x.tahun === pq.tahun && x.kuartal === pq.kuartal); if (!f) { f = { id: 'f' + Date.now().toString(36) + fNew.length, tahun: pq.tahun, kuartal: pq.kuartal, ket: '' }; fNew.push(f); } }
        else warn.push('Baris ' + line + ': periode "' + g('Periode') + '" tidak dikenali (contoh: Q1 2026/2027), memakai ' + (defFu ? fuName(defFu) : 'periode terpilih'));
      }
      if (!f) f = defFu;
      if (!f) { warn.push('Baris ' + line + ': belum ada Follow Up Audit, dilewati'); return; }
      const kk = key(g('Deskripsi'), k.id, due, f.id);
      if (seen.has(kk)) { dup++; return; }
      seen.add(kk);
      let persen = null;
      if (g('Persentase')) { const n = Number(g('Persentase').replace('%', '').replace(',', '.')); if (Number.isFinite(n) && n >= 0 && n <= 100) persen = Math.round(n); else warn.push('Baris ' + line + ': persentase "' + g('Persentase') + '" tidak valid (0–100), dikosongkan'); }
      iNew.push({ persen, deskripsi: g('Deskripsi'), fu: f.id, kebun: k.id, pic: g('PIC') || k.pic || '', due, prioritas, status, kategori: g('Bagian'), auditor: g('Tim Auditor') });
    });
    return { iNew, kNew, fNew, warn, dup, empty, all: all() };
  }

  function importPreview(res, fname) {
    if (res.error) return toast(res.error);
    if (!res.iNew.length) return toast(res.dup ? 'Semua ' + res.dup + ' baris sudah ada (duplikat), tidak ada yang diimpor' : 'Tidak ada baris data yang bisa diimpor');
    const kName = id => (res.all.find(k => k.id === id) || {}).nama || '—';
    const sample = res.iNew.slice(0, 5).map(i => `<tr><td>${esc(i.deskripsi)}</td><td>${esc(kName(i.kebun))}</td><td>${fmt(i.due)}</td><td>${STATUS[i.status].label}</td></tr>`).join('');
    const info = [`<b>${res.iNew.length}</b> temuan siap diimpor`];
    if (res.kNew.length) info.push(`<b>${res.kNew.length}</b> kebun baru akan dibuat: ${res.kNew.map(k => esc(k.nama)).join(', ')}`);
    const per = [...new Set(res.iNew.map(i => fuLabel(i.fu) || (res.fNew.find(f => f.id === i.fu) ? fuName(res.fNew.find(f => f.id === i.fu)) : '')))].filter(Boolean);
    info.push('Follow Up Audit: <b>' + per.map(esc).join(', ') + '</b>' + (res.fNew.length ? ' (' + res.fNew.length + ' periode baru akan dibuat)' : ''));
    if (res.dup) info.push(`${res.dup} baris duplikat dilewati`);
    if (res.empty) info.push(`${res.empty} baris tanpa deskripsi dilewati`);
    const warn = res.warn.length ? `<div class="warnbox"><b>${res.warn.length} peringatan</b><br>${res.warn.slice(0, 6).map(esc).join('<br>')}${res.warn.length > 6 ? `<br>…dan ${res.warn.length - 6} lainnya` : ''}</div>` : '';
    modal(`<h2>Pratinjau impor</h2><p style="color:var(--muted);font-size:12.5px;margin-bottom:10px">${esc(fname)}</p>
      <ul style="margin:0 0 4px 18px;line-height:1.7">${info.map(x => `<li>${x}</li>`).join('')}</ul>${warn}
      <div class="pvw"><table class="pv"><thead><tr><th>Deskripsi</th><th>Kebun</th><th>Jatuh tempo</th><th>Status</th></tr></thead><tbody>${sample}</tbody></table></div>
      ${res.iNew.length > 5 ? `<div style="font-size:12px;color:var(--muted)">…dan ${res.iNew.length - 5} baris lainnya</div>` : ''}
      <div class="actions"><button type="button" class="btn" data-close>Batal</button><button class="btn primary">Impor ${res.iNew.length} temuan</button></div>`,
      async (_, close) => {
        await api('POST', '/api/bulk', { fu: res.fNew, kebun: res.kNew, items: res.iNew });
        await refresh(); close(); toast(res.iNew.length + ' temuan berhasil diimpor'); render();
      }, 'wide');
  }

  async function importFile(file) {
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) return toast('Ukuran file melebihi 10 MB');
    try {
      const buf = await file.arrayBuffer(), u8 = new Uint8Array(buf);
      let rows;
      if (u8[0] === 0x50 && u8[1] === 0x4b) {
        toast('Membaca file Excel…');
        const r = await fetch('/api/parse-xlsx', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream', 'X-Requested-With': 'fetch' }, body: buf });
        const j = await r.json().catch(() => ({}));
        if (r.status === 401) { me = null; render(); return toast('Sesi berakhir, silakan masuk lagi'); }
        if (!r.ok) throw new Error(j.error || 'Gagal membaca file Excel');
        rows = j.rows;
      } else if (u8[0] === 0xD0 && u8[1] === 0xCF) {
        return toast('Format .xls (Excel lama) belum didukung. Buka di Excel, lalu Simpan Sebagai .xlsx');
      } else rows = parseCSV(new TextDecoder('utf-8').decode(u8));
      importPreview(buildImport(rows), file.name);
    } catch (e) { toast(e.message); }
  }
  function downloadTemplate() {
    const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
    const per = 'Q' + curPeriod().kuartal + ' ' + curPeriod().tahun + '/' + (curPeriod().tahun + 1);
    const lines = [COLS.map(q).join(','),
      ['', per, 'Selisih stok pupuk di gudang', 'Kebun Suka Makmur', 'Tim Audit 1', 'Inventory', 'Budi Santoso', '6281234567890', addDays(14), 'Dalam proses', 'Tinggi', '40'].map(q).join(','),
      ['', per, 'Kelengkapan APD di gudang pupuk', 'Kebun Harapan Jaya', 'Tim Audit 2', 'K3', 'Siti Rahmawati', '6281234567891', addDays(21), 'Menunggu verifikasi', 'Sedang', ''].map(q).join(',')];
    const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const el = document.createElement('a'); el.href = URL.createObjectURL(blob); el.download = 'template-impor-temuan.csv'; el.click();
    setTimeout(() => URL.revokeObjectURL(el.href), 1000);
  }

  /* ---------- modals ---------- */
  // tutup dengan animasi; aman bila modal lain sudah menggantikan sebelum animasi selesai
  function closeModal() {
    const root = $('#modal-root'), ov = root.firstChild;
    if (!ov || ov.classList.contains('closing')) return;
    ov.classList.add('closing');
    const done = () => { if (root.firstChild === ov) root.innerHTML = ''; };
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return done();
    setTimeout(done, 170);
  }
  function modal(html, onSubmit, cls = '') {
    const root = $('#modal-root');
    root.innerHTML = `<div class="overlay"><form class="modal ${cls}">${html}</form></div>`;
    const close = closeModal;
    root.firstChild.addEventListener('mousedown', e => { if (e.target === root.firstChild) close(); });
    $$('[data-close]', root).forEach(b => b.onclick = close);
    $('form', root).onsubmit = async e => {
      e.preventDefault();
      if (!onSubmit) return;
      const btn = $('button:not([type=button])', root); if (btn) btn.disabled = true;
      try { await onSubmit(Object.fromEntries(new FormData(e.target)), close); }
      catch (x) { toast(x.message); }
      if (btn) btn.disabled = false;
    };
    const f = $('input,select', root); f && f.focus();
  }
  const auditorList = () => [...new Set(db.items.map(i => i.auditor).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  const kOptions = sel => db.kebun.map(k => `<option value="${esc(k.id)}" ${k.id === sel ? 'selected' : ''}>${esc(k.nama)}</option>`).join('');
  function findingModal(it, preset = {}) {
    if (!db.fu.length) return toast('Buat Follow Up Audit terlebih dahulu (menu Follow Up Audit)');
    if (!db.kebun.length) return toast('Tambahkan kebun terlebih dahulu');
    const defFu = preset.fu || (ui.fu !== 'all' ? ui.fu : fuSorted()[0].id);
    const e = it || { deskripsi: '', fu: defFu, kebun: preset.kebun || db.kebun[0].id, pic: '', due: addDays(14), prioritas: 'Sedang', status: 'proc', kategori: preset.kategori || '', auditor: '', persen: null };
    modal(`<h2>${it ? 'Ubah temuan' : 'Tambah temuan'}</h2>
      <div class="field"><label>Deskripsi temuan</label><input name="deskripsi" required maxlength="300" value="${esc(e.deskripsi)}" placeholder="mis. Selisih stok pupuk di gudang"></div>
      <div class="row2"><div class="field"><label>Follow Up Audit</label><select name="fu" required>${fuSorted().map(f => `<option value="${esc(f.id)}" ${f.id === e.fu ? 'selected' : ''}>Follow Up Audit ${fuName(f)}</option>`).join('')}</select></div>
        <div class="field"><label>Kebun</label><select name="kebun">${kOptions(e.kebun)}</select></div></div>
      <div class="row2"><div class="field"><label>Bagian</label><input name="kategori" list="bagian-list" maxlength="60" autocomplete="off" value="${esc(e.kategori || '')}" placeholder="mis. Inventory"><datalist id="bagian-list">${bagianList().map(b => `<option value="${esc(b)}"></option>`).join('')}</datalist></div>
        <div class="field"><label>PIC</label><input name="pic" value="${esc(e.pic)}" placeholder="Otomatis dari kebun"></div></div>
      <div class="row2"><div class="field"><label>Jatuh tempo</label><input type="date" name="due" required value="${esc(e.due)}"></div>
        <div class="field"><label>Prioritas</label><select name="prioritas">${Object.keys(PRI).map(p => `<option ${p === e.prioritas ? 'selected' : ''}>${p}</option>`).join('')}</select></div></div>
      <div class="row2"><div class="field"><label>Status</label><select name="status">${Object.entries(STATUS).map(([k, v]) => `<option value="${k}" ${k === e.status ? 'selected' : ''}>${v.label}</option>`).join('')}</select></div>
        <div class="field"><label>Tim Auditor (penanggung jawab)</label><input name="auditor" list="auditor-list" maxlength="80" autocomplete="off" value="${esc(e.auditor || '')}" placeholder="mis. Tim Audit Kebun 1"><datalist id="auditor-list">${auditorList().map(a => `<option value="${esc(a)}"></option>`).join('')}</datalist></div></div>
      <div class="field"><label>% Progres (manual, 0–100)</label><input type="number" name="persen" min="0" max="100" step="1" inputmode="numeric" value="${e.persen === null || e.persen === undefined ? '' : esc(e.persen)}" placeholder="mis. 40"><small class="fhint">Dipakai bila temuan tidak punya berkas Excel dengan kolom Status. Bila ada berkas, persentase dihitung otomatis dari poinnya; bila status Selesai, otomatis 100%.</small></div>
      <div class="field"><label>Berkas pendukung (Excel / Word, maks. 50 MB)</label><div id="fbox" class="fbox"></div><input type="hidden" name="file" value="${esc(e.file || '')}"><input type="file" id="ffile" hidden accept=".xlsx,.xlsm,.xls,.csv,.docx,.doc"></div>
      <div class="actions"><button type="button" class="btn" data-close>Batal</button><button class="btn primary">Simpan</button></div>`,
      async (d, close) => {
        if ($('#fbox') && $('#fbox').dataset.busy) throw new Error('Tunggu unggahan berkas selesai dulu');
        d.pic = d.pic.trim() || kebunOf(d.kebun).pic;
        if (it) await api('PUT', `/api/items/${encodeURIComponent(it.id)}`, d); else await api('POST', '/api/items', d);
        await refresh(); close(); toast(it ? 'Temuan diperbarui' : 'Temuan ditambahkan'); render();
      });
    bindFileBox();
  }
  function bindFileBox() {
    const root = $('#modal-root'), box = $('#fbox', root), hid = $('input[name=file]', root), pick = $('#ffile', root);
    if (!box) return;
    let meta = (db.files || []).find(f => f.id === hid.value) || null;
    const paint = () => {
      if (meta) {
        box.innerHTML = `<div class="fcard"><div class="fc-top">${ic('clip')}<div class="fc-n"><b>${esc(meta.name)}</b><span>${fmtSize(meta.size)}</span></div>
          <a class="btn sm" href="${esc(fileHref(meta))}">${ic('down', 'style="width:13px;height:13px"')}Unduh</a><button type="button" class="btn sm" data-fb="pick">Ganti</button><button type="button" class="btn sm" style="color:var(--red)" data-fb="rm">Hapus</button></div>${statsBlock(meta)}</div>`;
      } else {
        box.innerHTML = `<button type="button" class="drop fdrop" data-fb="pick">${ic('up', 'style="width:20px;height:20px"')}<b>Pilih berkas Excel atau Word</b><small>.xlsx, .xls, .csv, .docx, .doc · maks. 50 MB · seret &amp; lepas juga bisa<br>Poin dihitung otomatis dari kolom Status di Excel</small></button>`;
      }
    };
    const upload = file => {
      if (!file) return;
      const ext = (file.name.match(/\.[^.]+$/) || [''])[0].toLowerCase();
      if (!FILE_EXT.includes(ext)) return toast('Hanya file Excel (.xlsx, .xls, .csv) atau Word (.docx, .doc)');
      if (file.size > MAX_FILE) return toast('Ukuran file melebihi 50 MB');
      box.dataset.busy = '1';
      box.innerHTML = `<div class="fcard"><div class="fc-top">${ic('clip')}<div class="fc-n"><b>${esc(file.name)}</b><span class="fup-p">Mengunggah… 0%</span></div></div><div class="bar" style="margin-top:10px"><i class="fup-b" style="width:0;background:var(--green-700);transition:width .2s"></i></div></div>`;
      const x = new XMLHttpRequest();
      x.open('POST', '/api/files');
      x.setRequestHeader('Content-Type', 'application/octet-stream'); x.setRequestHeader('X-Requested-With', 'fetch'); x.setRequestHeader('X-File-Name', encodeURIComponent(file.name));
      x.upload.onprogress = ev => { if (!ev.lengthComputable) return; const p = Math.min(99, Math.round(ev.loaded / ev.total * 100)); const a = $('.fup-p', box), b = $('.fup-b', box); if (a) a.textContent = 'Mengunggah… ' + p + '%'; if (b) b.style.width = p + '%'; };
      x.onload = () => {
        delete box.dataset.busy; let j = {}; try { j = JSON.parse(x.responseText); } catch (e) { }
        if (x.status === 201) { meta = j; hid.value = j.id; toast('Berkas diunggah'); }
        else toast(x.status === 401 ? 'Sesi berakhir, silakan masuk lagi' : j.error || 'Gagal mengunggah berkas');
        paint();
      };
      x.onerror = () => { delete box.dataset.busy; toast('Gagal mengunggah berkas. Periksa koneksi ke server.'); paint(); };
      x.send(file);
    };
    box.addEventListener('click', e => {
      const b = e.target.closest('[data-fb]'); if (!b) return;
      if (b.dataset.fb === 'pick') pick.click();
      else if (b.dataset.fb === 'rm') { meta = null; hid.value = ''; paint(); }
    });
    pick.onchange = () => { upload(pick.files[0]); pick.value = ''; };
    ['dragover', 'dragenter'].forEach(ev => box.addEventListener(ev, e => { e.preventDefault(); box.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(ev => box.addEventListener(ev, e => { e.preventDefault(); box.classList.remove('over'); }));
    box.addEventListener('drop', e => upload(e.dataTransfer.files[0]));
    paint();
  }
  function fileModal(it) {
    const f = fileOf(it); if (!f) return toast('Temuan ini belum punya berkas');
    modal(`<h2>Berkas &amp; poin</h2><p style="color:var(--muted);font-size:12.5px;margin-bottom:12px">${esc(it.deskripsi)} · ${esc(it.id)}</p>
      <div class="fcard"><div class="fc-top">${ic('clip')}<div class="fc-n"><b>${esc(f.name)}</b><span>${fmtSize(f.size)}</span></div></div>${statsBlock(f)}</div>
      <div class="actions" style="flex-wrap:wrap"><button type="button" class="btn" data-close>Tutup</button>
        <button type="button" class="btn" data-act="file-copy" data-fid="${esc(f.id)}">${ic('link', 'style="width:14px;height:14px"')}Salin tautan</button>
        <a class="btn" href="${esc(fileHref(f))}">${ic('down', 'style="width:14px;height:14px"')}Unduh</a>
        <button type="button" class="btn primary" data-row="wa" data-id="${esc(it.id)}">${ic('chat', 'style="width:14px;height:14px"')}Kirim ke PIC</button></div>`);
  }
  function kebunModal(k) {
    const e = k || { nama: '', prov: '', divisi: '', pic: '', wa: '' };
    modal(`<h2>${k ? 'Ubah kebun' : 'Tambah kebun'}</h2>
      <div class="field"><label>Nama kebun</label><input name="nama" required value="${esc(e.nama)}"></div>
      <div class="row2"><div class="field"><label>Provinsi</label><input name="prov" required value="${esc(e.prov)}"></div>
        <div class="field"><label>Divisi</label><input name="divisi" required value="${esc(e.divisi)}"></div></div>
      <div class="row2"><div class="field"><label>Penanggung jawab (PIC)</label><input name="pic" required value="${esc(e.pic)}"></div>
        <div class="field"><label>Nomor WhatsApp</label><input name="wa" required inputmode="numeric" value="${esc(e.wa)}" placeholder="628123456789"></div></div>
      <div class="actions"><button type="button" class="btn" data-close>Batal</button><button class="btn primary">Simpan</button></div>`,
      async (d, close) => {
        d.wa = d.wa.replace(/\D/g, '').replace(/^0/, '62');
        if (k) await api('PUT', `/api/kebun/${encodeURIComponent(k.id)}`, d); else await api('POST', '/api/kebun', d);
        await refresh(); close(); toast(k ? 'Kebun diperbarui' : 'Kebun ditambahkan'); render();
      });
  }
  function myPwModal() {
    modal(`<h2>Ganti kata sandi</h2>
      <div class="field"><label>Kata sandi saat ini</label><input type="password" name="current" required autocomplete="current-password"></div>
      <div class="field"><label>Kata sandi baru (min. 8 karakter)</label><input type="password" name="next" required minlength="8" autocomplete="new-password"></div>
      <div class="actions"><button type="button" class="btn" data-close>Batal</button><button class="btn primary">Simpan</button></div>`,
      async (d, close) => { await api('POST', '/api/me/password', d); close(); toast('Kata sandi diganti'); });
  }
  function userModal() {
    modal(`<h2>Tambah pengguna</h2>
      <div class="field"><label>Nama lengkap</label><input name="name" required></div>
      <div class="row2"><div class="field"><label>Username</label><input name="username" required pattern="[A-Za-z0-9._\\-]{3,40}" autocapitalize="none"></div>
        <div class="field"><label>Peran</label><select name="role"><option value="user">Pengguna</option><option value="admin">Admin</option></select></div></div>
      <div class="field"><label>Kata sandi awal (min. 8 karakter)</label><input type="text" name="password" required minlength="8" autocomplete="off"></div>
      <div class="actions"><button type="button" class="btn" data-close>Batal</button><button class="btn primary">Simpan</button></div>`,
      async (d, close) => { await api('POST', '/api/users', d); await loadUsers(); close(); toast('Pengguna ditambahkan'); render(); });
  }
  function userPwModal(u) {
    modal(`<h2>Atur kata sandi — ${esc(u.name)}</h2>
      <div class="field"><label>Kata sandi baru (min. 8 karakter)</label><input type="text" name="password" required minlength="8" autocomplete="off"></div>
      <p style="font-size:12px;color:var(--muted)">Pengguna tersebut akan otomatis keluar dari semua perangkat.</p>
      <div class="actions"><button type="button" class="btn" data-close>Batal</button><button class="btn primary">Simpan</button></div>`,
      async (d, close) => { await api('PUT', `/api/users/${u.id}/password`, d); close(); toast('Kata sandi diatur'); });
  }
  const waLink = (pic, wa, deskripsi, due, f) =>
    `https://wa.me/${wa}?text=${encodeURIComponent(`Halo ${pic}, mengingatkan tindak lanjut temuan audit: "${deskripsi}"${due ? ` (jatuh tempo ${fmt(due)})` : ''}. Mohon update progresnya. Terima kasih.${f ? `\n\nBerkas pendukung (${f.name}, ${fmtSize(f.size)}):\n${fileShare(f)}` : ''}`)}`;

  async function loadCfg() { try { cfg = await api('GET', '/api/config'); } catch (e) { } }
  async function loadUsers() { users = await api('GET', '/api/users'); }

  /* ---------- render ---------- */
  function loginView() {
    return `<div class="login-wrap"><form class="login" id="login">
      <div class="brand"><div class="logo">AF</div><div><b>Audit Follow Up</b><span>Julong Grup Indonesia</span></div></div>
      <h2>Masuk</h2><p>Gunakan akun yang diberikan oleh admin.</p>
      <div class="field"><label>Username</label><input name="username" required autocomplete="username" autocapitalize="none" autofocus></div>
      <div class="field"><label>Kata sandi</label><input type="password" name="password" required autocomplete="current-password"></div>
      <div class="err" id="login-err"></div>
      <button class="btn primary">Masuk</button></form></div>`;
  }
  function render() {
    if (!ready) { $('#app').innerHTML = ''; return; }
    if (!me) { $('#app').innerHTML = loginView(); return; }
    const key = route();
    if (key === 'pengguna' && !users) loadUsers().then(render).catch(e => toast(e.message));
    const body = { ringkasan: pageRingkasan, followup: pageFollowup, temuan: pageTemuan, kebun: pageKebun, pengingat: pageReminder, impor: pageImpor, pengguna: pagePengguna }[key]();
    const keep = document.activeElement && document.activeElement.id === 'q' ? document.activeElement.selectionStart : null;
    $('#app').innerHTML = shell(key, body);
    if (render.last !== undefined && render.last !== key) { const c = $('.content'); if (c) c.classList.add('enter'); }
    render.last = key;
    if (keep !== null) { const q = $('#q'); q.focus(); q.setSelectionRange(keep, keep); }
    if (key === 'impor') bindImport();
  }
  function bindImport() {
    const drop = $('#drop'), file = $('#file');
    file.onchange = () => importFile(file.files[0]);
    ['dragover', 'dragenter'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', e => importFile(e.dataTransfer.files[0]));
  }

  function settingsModal() {
    modal(`<h2>Pengaturan</h2>
      <p style="color:var(--muted);margin-bottom:14px">Masuk sebagai <b>${esc(me.name)}</b> (@${esc(me.username)}) · ${me.role === 'admin' ? 'Admin' : 'Pengguna'}</p>
      <div class="actions" style="justify-content:flex-start;flex-wrap:wrap">
        <button type="button" class="btn" data-act="my-pw">Ganti kata sandi</button>
        <button type="button" class="btn" data-act="set-base">Alamat tautan berkas</button>
        ${me.role === 'admin' ? `<button type="button" class="btn" data-act="seed">Muat data contoh</button><button type="button" class="btn" data-act="clear" style="color:var(--red)">Kosongkan semua data</button>` : ''}
        <button type="button" class="btn" data-act="logout">Keluar</button>
        <button type="button" class="btn" data-close>Tutup</button></div>`);
  }

  /* ---------- events ---------- */
  document.addEventListener('click', async e => {
    const t = e.target.closest('[data-act],[data-go],[data-menu],[data-row],[data-krow],[data-urow],[data-pg],[data-wa-k]');
    if (!t) { if (ui.menu) { ui.menu = null; render(); } return; }
    const d = t.dataset;
    try {
      if (d.go) location.hash = '#/' + d.go;
      else if (d.pg) { ui.page = +d.pg; render(); }
      else if (d.menu) { ui.menu = ui.menu === d.menu ? null : d.menu; render(); }
      else if (d.waK) { const k = db.kebun.find(x => x.id === d.waK); window.open(`https://wa.me/${k.wa}`, '_blank', 'noopener'); }
      else if (d.act === 'add-fu') fuModal();
      else if (d.act === 'fu-select') { setFu(d.id); render(); }
      else if (d.act === 'fu-edit') fuModal(fuOf(d.id));
      else if (d.act === 'fu-del') {
        const f = fuOf(d.id); if (!f) return;
        const n = db.items.filter(i => i.fu === f.id).length;
        if (!confirm(`Hapus Follow Up Audit ${fuName(f)} beserta ${n} temuannya? Tindakan ini tidak bisa dibatalkan.`)) return;
        await api('DELETE', `/api/fu/${encodeURIComponent(f.id)}`); await refresh(); toast('Follow Up Audit dihapus'); render();
      }
      else if (d.act === 'add-in') findingModal(null, { fu: d.fu, kebun: d.k, kategori: d.b });
      else if (d.act === 'add-finding') findingModal();
      else if (d.act === 'add-kebun') kebunModal();
      else if (d.act === 'add-user') userModal();
      else if (d.act === 'side-toggle') {
        const l = $('.layout'); if (!l) return;
        ui.side = !l.classList.contains('collapsed'); l.classList.toggle('collapsed', ui.side); lsSet('af.side', ui.side ? '1' : '0');
        t.title = t.ariaLabel = ui.side ? 'Perbesar menu' : 'Perkecil menu';
      }
      else if (d.act === 'file-copy') { const f = (db.files || []).find(x => x.id === d.fid); if (f) await copyText(fileShare(f)); }
      else if (d.act === 'set-base') {
        const v = prompt('Alamat server untuk tautan berkas yang dikirim ke PIC, contoh: http://192.168.1.10:3000\nKosongkan untuk otomatis.', lsGet('af.base') || baseUrl());
        if (v === null) return;
        if (v.trim() && !/^https?:\/\/\S+$/i.test(v.trim())) return toast('Alamat harus diawali http:// atau https://');
        lsSet('af.base', v.trim()); toast(v.trim() ? 'Alamat tautan disimpan' : 'Alamat tautan memakai pengaturan otomatis');
      }
      else if (d.act === 'menu') document.body.classList.toggle('nav-open');
      else if (d.act === 'menu-close') document.body.classList.remove('nav-open');
      else if (d.act === 'export') exportCSV();
      else if (d.act === 'template') downloadTemplate();
      else if (d.act === 'settings') settingsModal();
      else if (d.act === 'my-pw') myPwModal();
      else if (d.act === 'logout') { await api('POST', '/api/logout'); me = null; users = null; db = { kebun: [], items: [], fu: [], files: [] }; refresh.last = null; $('#modal-root').innerHTML = ''; render(); }
      else if (d.act === 'seed') {
        if (!confirm('Mengganti SELURUH data yang ada dengan data contoh. Lanjutkan?')) return;
        await api('POST', '/api/bulk', { replace: true, ...seed() }); await refresh(); $('#modal-root').innerHTML = ''; toast('Data contoh dimuat'); render();
      } else if (d.act === 'clear') {
        if (!confirm('Hapus SEMUA kebun dan temuan? Tindakan ini tidak bisa dibatalkan.')) return;
        await api('POST', '/api/bulk', { replace: true, fu: [], kebun: [], items: [] }); await refresh(); $('#modal-root').innerHTML = ''; toast('Semua data dihapus'); render();
      } else if (d.act === 'help') modal(`<h2>Pusat bantuan</h2><p style="color:#46564c;line-height:1.6">• <b>Follow Up Audit</b>: pilih triwulan di bagian atas layar (Q1 Sep–Des, Q2 Jan–Apr, Q3 Mei–Agu); buat dan kelola di menu Follow Up Audit (triwulan → kebun → bagian).<br>• <b>Tambah temuan</b>: klik tombol hijau di pojok kanan atas.<br>• <b>Ubah / hapus / tandai selesai</b>: klik tombol ••• pada baris temuan.<br>• <b>Hubungi PIC</b>: membuka WhatsApp dengan pesan pengingat siap kirim.<br>• <b>Berkas pendukung</b>: di form temuan, unggah Excel/Word (maks. 50 MB). Poin selesai, sedang progres, dan tidak ada progres dihitung otomatis dari kolom <i>Status</i> di Excel; tombol <i>Hubungi PIC</i> menyertakan tautan unduh berkas.<br>• <b>Sidebar</b>: klik tombol panah di tepi menu untuk memperkecil/memperbesar.<br>• <b>Impor</b>: unggah file Excel (.xlsx) atau CSV di menu Impor &amp; ekspor; unduh template untuk format kolomnya.<br>• Data dibagikan ke semua pengguna dan diperbarui otomatis setiap ±15 detik.</p><div class="actions"><button type="button" class="btn primary" data-close>Mengerti</button></div>`);
      else if (d.row) {
        const it = db.items.find(x => x.id === d.id); ui.menu = null; if (!it) return render();
        if (d.row === 'wa') { window.open(waLink(it.pic, kebunOf(it.kebun).wa, it.deskripsi, it.due, fileOf(it)), '_blank', 'noopener'); return render(); }
        if (d.row === 'file') { render(); return fileModal(it); }
        if (d.row === 'edit') { render(); return findingModal(it); }
        if (d.row === 'done') { await api('PUT', `/api/items/${encodeURIComponent(it.id)}`, { status: 'done' }); toast('Ditandai selesai'); }
        else if (d.row === 'reopen') { await api('PUT', `/api/items/${encodeURIComponent(it.id)}`, { status: 'proc' }); toast('Dibuka kembali'); }
        else if (d.row === 'del') { if (!confirm('Hapus temuan ini?')) return render(); await api('DELETE', `/api/items/${encodeURIComponent(it.id)}`); toast('Temuan dihapus'); }
        await refresh(); render();
      } else if (d.krow) {
        const k = db.kebun.find(x => x.id === d.id); ui.menu = null; if (!k) return render();
        if (d.krow === 'edit') { render(); return kebunModal(k); }
        if (!confirm(`Hapus ${k.nama} beserta seluruh temuannya?`)) return render();
        await api('DELETE', `/api/kebun/${encodeURIComponent(k.id)}`); await refresh(); toast('Kebun dihapus'); render();
      } else if (d.urow) {
        const u = users.find(x => x.id === +d.id); if (!u) return;
        if (d.urow === 'pw') return userPwModal(u);
        if (!confirm(`Hapus pengguna ${u.name}?`)) return;
        await api('DELETE', `/api/users/${u.id}`); await loadUsers(); toast('Pengguna dihapus'); render();
      }
    } catch (x) { toast(x.message); }
  });
  document.addEventListener('submit', async e => {
    if (e.target.id !== 'login') return;
    e.preventDefault();
    const f = new FormData(e.target), err = $('#login-err'); err.textContent = '';
    try {
      me = await api('POST', '/api/login', { username: f.get('username'), password: f.get('password') });
      refresh.last = null; users = null; await refresh(); loadCfg(); location.hash = '#/ringkasan'; render();
    } catch (x) { err.textContent = x.message; }
  });
  document.addEventListener('input', e => { if (e.target.id === 'q') { ui.q = e.target.value; ui.page = 1; render(); } });
  document.addEventListener('toggle', e => { const el = e.target; if (el.dataset && el.dataset.key) { if (el.open) ui.closed.delete(el.dataset.key); else ui.closed.add(el.dataset.key); } }, true);
  document.addEventListener('change', e => { if (e.target.id === 'fu-sel') { setFu(e.target.value); render(); return; } if (e.target.id === 'fs') { ui.status = e.target.value; ui.page = 1; render(); } });
  window.addEventListener('hashchange', () => { document.body.classList.remove('nav-open'); ui.menu = null; ui.page = 1; render(); window.scrollTo(0, 0); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

  (async function boot() {
    try { me = await api('GET', '/api/me'); await refresh(); loadCfg(); } catch (e) { me = null; }
    ready = true; render(); setInterval(poll, 15000);
  })();
})();
