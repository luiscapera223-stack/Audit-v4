// Audit Follow Up v4 — server Node.js + SQLite (node:sqlite bawaan Node 22.13+), tanpa paket tambahan.
// Jalankan: node server.js
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const os = require('os');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC = path.join(__dirname, 'public');
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'audit.db');
const SESSION_MS = 7 * 24 * 3600 * 1000;
const MAX_FILE = 50 * 1024 * 1024; // batas berkas temuan: 50 MB
const FILES_DIR = path.join(path.dirname(DB_PATH), 'files');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
fs.mkdirSync(FILES_DIR, { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec(`
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', salt TEXT NOT NULL, hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS kebun(id TEXT PRIMARY KEY, nama TEXT NOT NULL, prov TEXT, divisi TEXT, pic TEXT, wa TEXT);
CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, deskripsi TEXT NOT NULL, kebun TEXT, pic TEXT, due TEXT, prioritas TEXT, status TEXT, kategori TEXT, fu TEXT);
CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY, name TEXT NOT NULL, size INTEGER NOT NULL, token TEXT UNIQUE NOT NULL, mode TEXT NOT NULL DEFAULT 'na', total INTEGER NOT NULL DEFAULT 0, done INTEGER NOT NULL DEFAULT 0, prog INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS fu(id TEXT PRIMARY KEY, tahun INTEGER NOT NULL, kuartal INTEGER NOT NULL, ket TEXT, UNIQUE(tahun,kuartal));
`);
// migrasi v3: kolom berkas di temuan
if (!db.prepare('PRAGMA table_info(items)').all().some(c => c.name === 'file')) db.exec('ALTER TABLE items ADD COLUMN file TEXT');
// migrasi v4.4: persentase progres manual (NULL = belum diisi)
if (!db.prepare('PRAGMA table_info(items)').all().some(c => c.name === 'persen')) db.exec('ALTER TABLE items ADD COLUMN persen INTEGER');
// migrasi v4.3: Tim Auditor (penanggung jawab temuan)
if (!db.prepare('PRAGMA table_info(items)').all().some(c => c.name === 'auditor')) db.exec("ALTER TABLE items ADD COLUMN auditor TEXT NOT NULL DEFAULT ''");
// Triwulan: Q1 = Sep–Des, Q2 = Jan–Apr, Q3 = Mei–Agu. "tahun" = tahun mulai tahun buku (Q1 2026 = Sep 2026, Q2/Q3 2026 = 2027).
const curPeriod = (d = new Date()) => { const m = d.getMonth(), y = d.getFullYear(); return m >= 8 ? { kuartal: 1, tahun: y } : m <= 3 ? { kuartal: 2, tahun: y - 1 } : { kuartal: 3, tahun: y - 1 }; };
// migrasi satu kali: periode lama (kuartal kalender Q1–Q4) dipetakan ke triwulan baru lewat bulan tengahnya; yang bertabrakan digabung.
if (db.prepare('PRAGMA user_version').get().user_version < 1) {
  db.exec('BEGIN');
  try {
    const keep = new Map();
    for (const r of db.prepare('SELECT * FROM fu ORDER BY tahun, kuartal').all()) {
      const mid = (r.kuartal - 1) * 3 + 1; // bulan tengah kuartal lama (0 = Jan)
      const q = mid >= 8 ? 1 : mid <= 3 ? 2 : 3, t = mid >= 8 ? r.tahun : r.tahun - 1, k = t + '-' + q;
      if (!keep.has(k)) keep.set(k, { id: r.id, tahun: t, kuartal: q, ket: r.ket || '' });
      else { db.prepare('UPDATE items SET fu=? WHERE fu=?').run(keep.get(k).id, r.id); const kk = keep.get(k); if (!kk.ket && r.ket) kk.ket = r.ket; }
    }
    db.exec('DELETE FROM fu');
    for (const o of keep.values()) db.prepare('INSERT INTO fu(id,tahun,kuartal,ket) VALUES(?,?,?,?)').run(o.id, o.tahun, o.kuartal, o.ket);
    db.exec('PRAGMA user_version = 1');
    db.exec('COMMIT');
    if (keep.size) console.log('Periode Follow Up lama dikonversi ke Triwulan (Q1 Sep–Des, Q2 Jan–Apr, Q3 Mei–Agu).');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}
// migrasi dari versi tanpa Follow Up: tambah kolom, lalu masukkan temuan lama ke triwulan berjalan
if (!db.prepare('PRAGMA table_info(items)').all().some(c => c.name === 'fu')) db.exec('ALTER TABLE items ADD COLUMN fu TEXT');
if (db.prepare("SELECT COUNT(*) c FROM items WHERE fu IS NULL OR fu=''").get().c > 0) {
  const { kuartal: q, tahun: t } = curPeriod();
  let f = db.prepare('SELECT id FROM fu WHERE tahun=? AND kuartal=?').get(t, q);
  if (!f) { f = { id: 'f' + crypto.randomBytes(5).toString('hex') }; db.prepare('INSERT INTO fu(id,tahun,kuartal,ket) VALUES(?,?,?,?)').run(f.id, t, q, ''); }
  db.prepare("UPDATE items SET fu=? WHERE fu IS NULL OR fu=''").run(f.id);
  console.log(`Temuan lama dimasukkan ke Follow Up Audit Q${q} ${t}/${t + 1}`);
}

/* ---------- util ---------- */
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const str = (v, n = 200) => String(v ?? '').trim().slice(0, n);
const ST = ['late', 'proc', 'wait', 'done'];
const PR = ['Tinggi', 'Sedang', 'Rendah'];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const bad = (msg, code = 400) => { throw new HttpError(code, msg); };

function tx(fn) {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}

function createUser(username, name, password, role = 'user') {
  username = str(username, 40).toLowerCase(); name = str(name, 80);
  if (!/^[a-z0-9._-]{3,40}$/.test(username)) bad('Username 3–40 karakter (huruf kecil, angka, titik, strip, garis bawah)');
  if (!name) bad('Nama wajib diisi');
  if (String(password || '').length < 8) bad('Kata sandi minimal 8 karakter');
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) bad('Username sudah dipakai', 409);
  const salt = crypto.randomBytes(16).toString('hex');
  db.prepare('INSERT INTO users(username,name,role,salt,hash) VALUES(?,?,?,?,?)').run(username, name, role === 'admin' ? 'admin' : 'user', salt, hashPw(String(password), salt));
}
function setPassword(id, password) {
  if (String(password || '').length < 8) bad('Kata sandi minimal 8 karakter');
  const salt = crypto.randomBytes(16).toString('hex');
  db.prepare('UPDATE users SET salt=?, hash=? WHERE id=?').run(salt, hashPw(String(password), salt), id);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
}

// admin pertama
if (db.prepare('SELECT COUNT(*) c FROM users').get().c === 0) {
  const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(6).toString('base64url');
  createUser('admin', 'Administrator', pw, 'admin');
  console.log('\n=== AKUN ADMIN DIBUAT ===\n  username : admin\n  password : ' + pw + '\n  (segera ganti lewat menu Pengaturan > Ganti kata sandi)\n');
}

/* ---------- data ---------- */
const nextIds = count => {
  let m = 0;
  for (const r of db.prepare("SELECT id FROM items WHERE id LIKE 'TMN-%'").all()) { const n = parseInt(r.id.split('-').pop(), 10); if (n > m) m = n; }
  const y = new Date().getFullYear();
  return Array.from({ length: count }, (_, i) => `TMN-${y}-${String(m + i + 1).padStart(3, '0')}`);
};
function cleanItem(b, base = null) {
  const o = base ? { ...base } : { deskripsi: '', kebun: '', pic: '', due: '', prioritas: 'Sedang', status: 'proc', kategori: '', fu: '', file: '', auditor: '', persen: null };
  if ('deskripsi' in b) o.deskripsi = str(b.deskripsi, 300);
  if ('kebun' in b) o.kebun = str(b.kebun, 60);
  if ('pic' in b) o.pic = str(b.pic, 80);
  if ('kategori' in b) o.kategori = str(b.kategori, 60);
  if ('auditor' in b) o.auditor = str(b.auditor, 80);
  o.auditor = o.auditor || '';
  if ('persen' in b) {
    if (b.persen === '' || b.persen === null) o.persen = null;
    else { const n = Number(String(b.persen).replace(',', '.').replace('%', '')); if (!Number.isFinite(n) || n < 0 || n > 100) bad('% progres harus angka 0–100'); o.persen = Math.round(n); }
  }
  if (o.persen === undefined) o.persen = null;
  if ('fu' in b) o.fu = str(b.fu, 60);
  if ('file' in b) { o.file = str(b.file, 60); if (o.file && !db.prepare('SELECT 1 FROM files WHERE id=?').get(o.file)) bad('Berkas tidak ditemukan, unggah ulang'); }
  o.file = o.file || '';
  if ('due' in b) { if (!DATE_RE.test(String(b.due))) bad('Format tanggal harus YYYY-MM-DD'); o.due = b.due; }
  if ('prioritas' in b) { if (!PR.includes(b.prioritas)) bad('Prioritas tidak valid'); o.prioritas = b.prioritas; }
  if ('status' in b) { if (!ST.includes(b.status)) bad('Status tidak valid'); o.status = b.status; }
  if (!o.deskripsi) bad('Deskripsi wajib diisi');
  if (!o.due) bad('Jatuh tempo wajib diisi');
  if (!o.fu || !db.prepare('SELECT 1 FROM fu WHERE id=?').get(o.fu)) bad('Pilih Follow Up Audit yang valid');
  return o;
}
function cleanKebun(b, base = null) {
  const o = base ? { ...base } : { nama: '', prov: '', divisi: '', pic: '', wa: '' };
  for (const [k, n] of [['nama', 100], ['prov', 60], ['divisi', 60], ['pic', 80]]) if (k in b) o[k] = str(b[k], n);
  if ('wa' in b) o.wa = String(b.wa ?? '').replace(/\D/g, '').slice(0, 16);
  if (!o.nama) bad('Nama kebun wajib diisi');
  return o;
}
function cleanFu(b, base = null) {
  const o = base ? { ...base } : { ...curPeriod(), ket: '' };
  if ('tahun' in b) o.tahun = parseInt(b.tahun, 10);
  if ('kuartal' in b) o.kuartal = parseInt(b.kuartal, 10);
  if ('ket' in b) o.ket = str(b.ket, 200);
  if (!(o.kuartal >= 1 && o.kuartal <= 3)) bad('Triwulan harus Q1, Q2, atau Q3');
  if (!(o.tahun >= 2000 && o.tahun <= 2100)) bad('Tahun tidak valid');
  return o;
}
const dupFu = (o, id) => db.prepare('SELECT 1 FROM fu WHERE tahun=? AND kuartal=? AND id<>?').get(o.tahun, o.kuartal, id || '');
const insFu = o => db.prepare('INSERT OR REPLACE INTO fu(id,tahun,kuartal,ket) VALUES(?,?,?,?)').run(o.id, o.tahun, o.kuartal, o.ket || '');
const insItem = o => db.prepare('INSERT OR REPLACE INTO items(id,deskripsi,kebun,pic,due,prioritas,status,kategori,fu,file,auditor,persen) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(o.id, o.deskripsi, o.kebun, o.pic, o.due, o.prioritas, o.status, o.kategori, o.fu, o.file || '', o.auditor || '', o.persen);
const insKebun = o => db.prepare('INSERT OR REPLACE INTO kebun(id,nama,prov,divisi,pic,wa) VALUES(?,?,?,?,?,?)').run(o.id, o.nama, o.prov, o.divisi, o.pic, o.wa);
const allData = () => ({
  fu: db.prepare('SELECT * FROM fu ORDER BY tahun, kuartal').all().map(r => ({ ...r })),
  kebun: db.prepare('SELECT * FROM kebun ORDER BY rowid').all().map(r => ({ ...r })),
  items: db.prepare('SELECT * FROM items ORDER BY id').all().map(r => ({ ...r, file: r.file || '', auditor: r.auditor || '' })),
  files: db.prepare('SELECT id,name,size,token,mode,total,done,prog FROM files').all().map(r => ({ ...r })),
});

/* ---------- berkas temuan (Excel / Word) ---------- */
function rmFile(id) {
  if (!id) return;
  if (db.prepare('SELECT 1 FROM items WHERE file=?').get(id)) return;
  if (!db.prepare('SELECT 1 FROM files WHERE id=?').get(id)) return;
  db.prepare('DELETE FROM files WHERE id=?').run(id);
  fs.rm(path.join(FILES_DIR, id), { force: true }, () => { });
}
// hapus berkas yang tidak dipakai temuan mana pun (mis. unggahan yang dibatalkan)
function gcFiles(minAgeMs) {
  const cut = Date.now() - minAgeMs;
  for (const r of db.prepare("SELECT id FROM files WHERE created<? AND id NOT IN (SELECT file FROM items WHERE file IS NOT NULL AND file<>'')").all(cut)) rmFile(r.id);
}
gcFiles(3600e3); setInterval(() => gcFiles(3600e3), 3600e3).unref();
const safeName = n => String(n || 'berkas').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim().slice(0, 120) || 'berkas';
const FILE_EXT = ['.xlsx', '.xlsm', '.xls', '.csv', '.docx', '.doc'];
const lanIps = () => Object.values(os.networkInterfaces()).flat().filter(a => a && a.family === 'IPv4' && !a.internal).map(a => a.address);

// Statistik poin dari Excel/CSV: cari kolom Status, hitung baris poin, yang selesai, dan yang belum.
const nrm = x => String(x ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
const STAT_HDR = new Set(['status', 'progress', 'progres', 'selesai', 'done', 'hasil', 'penyelesaian']);
function isDoneVal(v) {
  v = nrm(v); if (!v) return false;
  if (/(^|\W)(belum|tidak|not|open|proses|pending|progress|sebagian|partial|outstanding|no|x)(\W|$)/.test(v)) return false;
  if (/^(✓|✔|☑|v|y|ya|yes|ok|true|1)$/.test(v)) return true;
  const pc = v.match(/^(\d+(?:[.,]\d+)?)\s*%$/); if (pc) return parseFloat(pc[1].replace(',', '.')) >= 100;
  return /(^|\W)(selesai|tuntas|done|closed?|completed?|complete|sudah|clear|cleared|beres)(\W|$)/.test(v);
}
// Tiga kelompok: 'done' (selesai), 'prog' (sedang progres), 'none' (belum ada progres / kosong).
const NEG_PROG = /(^|\W)(belum|tidak|tanpa|bukan|no|not)\s+(ada\s+)?(di\s?)?(proses\w*|progres+s?\w*|dikerjakan|dikerjain|dimulai|started|kerja)(\W|$)/;
const IS_PROG = /(^|\W)(proses|diproses|progres+s?|sebagian|partial|ongoing|on[- ]going|berjalan|dikerjakan|pengerjaan|sedang|wip|menunggu|verifikasi|in ?progress|follow ?up)(\W|$)/;
function classifyVal(v) {
  if (isDoneVal(v)) return 'done';
  const n = nrm(v); if (!n) return 'none';
  if (NEG_PROG.test(n)) return 'none';
  if (IS_PROG.test(n)) return 'prog';
  const pc = n.match(/^(\d+(?:[.,]\d+)?)\s*%$/); if (pc && parseFloat(pc[1].replace(',', '.')) > 0) return 'prog';
  return 'none';
}
function pointStats(rows) {
  const filled = r => (r || []).filter(c => String(c ?? '').trim() !== '').length;
  let hi = -1, sc = -1;
  for (let i = 0; i < Math.min(rows.length, 15) && hi < 0; i++) {
    (rows[i] || []).forEach((c, j) => { const n = nrm(c); if (sc < 0 && (STAT_HDR.has(n) || /^status\b/.test(n))) { hi = i; sc = j; } });
  }
  const hasStatus = hi >= 0;
  if (!hasStatus) hi = rows.findIndex(r => filled(r) > 0);
  if (hi < 0) return { mode: 'nostat', total: 0, done: 0, prog: 0 };
  let total = 0, done = 0, prog = 0;
  for (const r of rows.slice(hi + 1)) {
    if (!filled(r)) continue;
    const first = nrm((r || []).find(c => String(c ?? '').trim() !== ''));
    if (/^(total|jumlah|grand total|sub ?total)\b/.test(first)) continue;
    const content = (r || []).some((c, j) => j !== sc && String(c ?? '').trim() !== '' && !/^\d+[.)]?$/.test(String(c).trim()));
    if (!content) continue;
    if (!hasStatus && filled(r) < 2) continue;
    total++;
    if (hasStatus) { const k = classifyVal(r[sc]); if (k === 'done') done++; else if (k === 'prog') prog++; }
  }
  return { mode: hasStatus ? 'stat' : 'nostat', total, done, prog };
}
function parseCsvRows(t) {
  const rows = []; let r = [], f = '', q = false;
  t = t.replace(/^\uFEFF/, '');
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ',' || c === ';') { r.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; r.push(f); rows.push(r); r = []; f = ''; }
    else f += c;
  }
  if (f || r.length) { r.push(f); rows.push(r); }
  return rows.filter(x => x.some(v => v.trim()));
}

/* ---------- pembaca XLSX minimal (zip + XML), tanpa dependensi ---------- */
function zipIndex(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('zip');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const idx = new Map();
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    idx.set(buf.toString('utf8', p + 46, p + 46 + nl), { method, csize, off });
    p += 46 + nl + el + cl;
  }
  return name => {
    const e = idx.get(name); if (!e) return null;
    const start = e.off + 30 + buf.readUInt16LE(e.off + 26) + buf.readUInt16LE(e.off + 28);
    const data = buf.subarray(start, start + e.csize);
    if (e.method === 0) return data;
    if (e.method === 8) return zlib.inflateRawSync(data, { maxOutputLength: 300 * 1024 * 1024 });
    throw new Error('zip');
  };
}
const xmlDecode = s => s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (m, e) => {
  e = e.toLowerCase();
  if (e === 'amp') return '&'; if (e === 'lt') return '<'; if (e === 'gt') return '>'; if (e === 'quot') return '"'; if (e === 'apos') return "'";
  try { return String.fromCodePoint(e[1] === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch { return ''; }
});
const xAttr = (s, n) => { const m = s.match(new RegExp('(?:^|\\s)' + n + '="([^"]*)"')); return m ? xmlDecode(m[1]) : undefined; };
const siText = x => { x = x.replace(/<rPh\b[\s\S]*?<\/rPh>/g, ''); let t = ''; for (const m of x.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)) t += m[1]; return xmlDecode(t); };
function dateStyles(xml) {
  const set = new Set(); if (!xml) return set;
  const fm = {};
  for (const m of xml.matchAll(/<numFmt\b([^>]*)\/?>/g)) { const id = xAttr(m[1], 'numFmtId'), code = xAttr(m[1], 'formatCode'); if (id !== undefined) fm[id] = code || ''; }
  const cx = xml.match(/<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/); if (!cx) return set;
  let i = 0;
  for (const m of cx[1].matchAll(/<xf\b([^>]*?)(?:\/>|>)/g)) {
    const id = xAttr(m[1], 'numFmtId'), n = +id, code = fm[id];
    const isDate = (n >= 14 && n <= 22) || (n >= 45 && n <= 47) ||
      (code && !/^general$/i.test(code) && /[dmyhs]/i.test(code.replace(/\[[^\]]*\]|"[^"]*"|\\./g, '')));
    if (isDate) set.add(i); i++;
  }
  return set;
}
const serialToISO = v => { const n = parseFloat(v); if (!isFinite(n) || n < 1 || n > 2958465) return null; return new Date(Date.UTC(1899, 11, 30) + Math.floor(n) * 864e5).toISOString().slice(0, 10); };
function parseXlsx(buf) {
  const get = zipIndex(buf);
  const txt = n => { const b = get(n); return b ? b.toString('utf8') : null; };
  const wb = txt('xl/workbook.xml'); if (!wb) throw new Error('xlsx');
  const sh = wb.match(/<sheet\b[^>]*>/); if (!sh) throw new Error('xlsx');
  const rid = xAttr(sh[0], 'r:id');
  let target = 'worksheets/sheet1.xml';
  const rels = txt('xl/_rels/workbook.xml.rels') || '';
  for (const m of rels.matchAll(/<Relationship\b([^>]*)\/?>/g)) if (xAttr(m[1], 'Id') === rid) { target = xAttr(m[1], 'Target') || target; break; }
  const sheet = txt(target.startsWith('/') ? target.slice(1) : 'xl/' + target); if (!sheet) throw new Error('xlsx');
  const sst = txt('xl/sharedStrings.xml');
  const shared = sst ? [...sst.matchAll(/<si\b[^>]*?(?:\/>|>([\s\S]*?)<\/si>)/g)].map(m => siText(m[1] || '')) : [];
  const dStyle = dateStyles(txt('xl/styles.xml'));
  const colIdx = ref => { let n = 0; for (const ch of ref.replace(/\d+/g, '')) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
  const rows = [];
  for (const rm of sheet.matchAll(/<row\b([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g)) {
    const rn = parseInt(xAttr(rm[1], 'r'), 10);
    if (rn > 20000 || rows.length >= 20000) break;
    if (rn) while (rows.length < rn - 1) rows.push([]); // jaga nomor baris sesuai Excel
    const row = [];
    for (const cm of (rm[2] || '').matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const a = cm[1], body = cm[2] || '', ref = xAttr(a, 'r'), t = xAttr(a, 't'), st = xAttr(a, 's');
      const ci = ref ? colIdx(ref) : row.length; if (ci < 0 || ci > 200) continue;
      const vm = body.match(/<v>([\s\S]*?)<\/v>/); const v = vm ? xmlDecode(vm[1]) : '';
      let val = '';
      if (t === 's') val = shared[+v] ?? '';
      else if (t === 'inlineStr') { const im = body.match(/<is\b[^>]*>([\s\S]*?)<\/is>/); val = im ? siText(im[1]) : ''; }
      else if (t === 'str') val = v;
      else if (t === 'b') val = v === '1' ? 'TRUE' : 'FALSE';
      else if (t === 'e') val = '';
      else val = (st !== undefined && dStyle.has(+st) && serialToISO(v)) || v;
      row[ci] = val;
    }
    const out = Array.from(row, x => x ?? '');
    while (out.length && out[out.length - 1] === '') out.pop();
    rows.push(out);
  }
  return rows;
}

// berkas lama: tambah kolom prog lalu hitung ulang dari file di disk (satu kali)
if (!db.prepare('PRAGMA table_info(files)').all().some(c => c.name === 'prog')) {
  db.exec('ALTER TABLE files ADD COLUMN prog INTEGER NOT NULL DEFAULT 0');
  for (const r of db.prepare("SELECT id,name FROM files WHERE mode='stat'").all()) {
    try {
      const buf = fs.readFileSync(path.join(FILES_DIR, r.id)), ext = path.extname(r.name).toLowerCase();
      const st = ext === '.csv' ? pointStats(parseCsvRows(buf.toString('utf8'))) : pointStats(parseXlsx(buf));
      db.prepare('UPDATE files SET total=?, done=?, prog=? WHERE id=?').run(st.total, st.done, st.prog, r.id);
    } catch (e) { /* biarkan; unggah ulang bila perlu */ }
  }
}

/* ---------- http helpers ---------- */
function send(res, code, obj, headers = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}
function readBody(req, limit = 6 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new HttpError(413, 'Data terlalu besar')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { if (!chunks.length) return resolve({}); try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new HttpError(400, 'JSON tidak valid')); } });
    req.on('error', reject);
  });
}
function readRaw(req, limit, msg = 'Ukuran file melebihi 10 MB') {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new HttpError(413, msg)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').map(s => s.trim().split(/=(.*)/s).slice(0, 2)).filter(a => a[0]));
function sessionUser(req) {
  const t = cookies(req).sid; if (!t) return null;
  const s = db.prepare('SELECT user_id, expires FROM sessions WHERE token=?').get(sha(t));
  if (!s || s.expires < Date.now()) return null;
  return db.prepare('SELECT id,username,name,role FROM users WHERE id=?').get(s.user_id) || null;
}
const isHttps = req => req.headers['x-forwarded-proto'] === 'https' || process.env.COOKIE_SECURE === '1';
const tries = new Map();
function throttle(key) {
  const now = Date.now(); const t = tries.get(key) || { n: 0, t: now };
  if (now - t.t > 10 * 60 * 1000) { t.n = 0; t.t = now; }
  t.n++; tries.set(key, t);
  if (t.n > 8) bad('Terlalu banyak percobaan. Coba lagi dalam beberapa menit.', 429);
}

/* ---------- API ---------- */
async function api(req, res, url) {
  const method = req.method, p = url.pathname;
  if (method !== 'GET' && req.headers['x-requested-with'] !== 'fetch') bad('Permintaan tidak valid', 403);

  if (p === '/api/health') return send(res, 200, { ok: true });

  if (p === '/api/login' && method === 'POST') {
    const b = await readBody(req);
    const username = str(b.username, 40).toLowerCase();
    throttle(`${req.socket.remoteAddress}|${username}`);
    const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
    const ok = u && crypto.timingSafeEqual(Buffer.from(hashPw(String(b.password || ''), u.salt), 'hex'), Buffer.from(u.hash, 'hex'));
    if (!ok) bad('Username atau kata sandi salah', 401);
    tries.delete(`${req.socket.remoteAddress}|${username}`);
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('DELETE FROM sessions WHERE expires < ?').run(Date.now());
    db.prepare('INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)').run(sha(token), u.id, Date.now() + SESSION_MS);
    return send(res, 200, { id: u.id, username: u.username, name: u.name, role: u.role },
      { 'Set-Cookie': `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_MS / 1000}${isHttps(req) ? '; Secure' : ''}` });
  }

  const me = sessionUser(req);
  if (!me) bad('Silakan masuk terlebih dahulu', 401);

  if (p === '/api/logout' && method === 'POST') {
    const t = cookies(req).sid; if (t) db.prepare('DELETE FROM sessions WHERE token=?').run(sha(t));
    return send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0' });
  }
  if (p === '/api/me' && method === 'GET') return send(res, 200, me);
  if (p === '/api/me/password' && method === 'POST') {
    const b = await readBody(req);
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(me.id);
    if (!crypto.timingSafeEqual(Buffer.from(hashPw(String(b.current || ''), u.salt), 'hex'), Buffer.from(u.hash, 'hex'))) bad('Kata sandi saat ini salah', 400);
    const keep = sha(cookies(req).sid);
    setPassword(me.id, b.next);
    db.prepare('INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)').run(keep, me.id, Date.now() + SESSION_MS); // tetap masuk di perangkat ini
    return send(res, 200, { ok: true });
  }

  if (p === '/api/parse-xlsx' && method === 'POST') {
    const buf = await readRaw(req, 10 * 1024 * 1024);
    if (buf.length < 4 || buf.readUInt32LE(0) !== 0x04034b50) bad('File bukan .xlsx yang valid. Di Excel, pilih Simpan Sebagai > Excel Workbook (.xlsx).');
    let rows; try { rows = parseXlsx(buf); } catch { bad('File Excel tidak dapat dibaca atau rusak'); }
    return send(res, 200, { rows });
  }

  if (p === '/api/config' && method === 'GET') return send(res, 200, { lan: lanIps(), port: +PORT, maxFile: MAX_FILE });

  if (p === '/api/files' && method === 'POST') {
    let name = 'berkas'; try { name = decodeURIComponent(String(req.headers['x-file-name'] || 'berkas')); } catch { }
    name = safeName(name);
    const ext = path.extname(name).toLowerCase();
    if (!FILE_EXT.includes(ext)) bad('Hanya file Excel (.xlsx, .xls, .csv) atau Word (.docx, .doc) yang boleh diunggah');
    if (+req.headers['content-length'] > MAX_FILE) bad('Ukuran file melebihi 50 MB', 413);
    const buf = await readRaw(req, MAX_FILE, 'Ukuran file melebihi 50 MB');
    if (!buf.length) bad('File kosong');
    const zip = buf.length > 4 && buf.readUInt32LE(0) === 0x04034b50, ole = buf.length > 4 && buf.readUInt32LE(0) === 0xe011cfd0;
    let st = { mode: 'na', total: 0, done: 0, prog: 0 };
    if (ext === '.xlsx' || ext === '.xlsm') {
      if (!zip) bad('File bukan .xlsx yang valid');
      let get; try { get = zipIndex(buf); if (!get('xl/workbook.xml')) throw new Error('x'); } catch { bad('File Excel tidak dapat dibaca atau rusak'); }
      try { st = pointStats(parseXlsx(buf)); } catch { st = { mode: 'nostat', total: 0, done: 0, prog: 0 }; }
    } else if (ext === '.docx') {
      let ok = false; try { ok = !!zipIndex(buf)('word/document.xml'); } catch { }
      if (!zip || !ok) bad('File bukan .docx yang valid');
    } else if (ext === '.xls' || ext === '.doc') {
      if (!ole) bad('File ' + ext + ' tidak valid');
    } else if (ext === '.csv') {
      if (zip || ole || buf.subarray(0, 2048).includes(0)) bad('File bukan CSV yang valid');
      st = pointStats(parseCsvRows(buf.toString('utf8')));
    }
    const id = 'b' + crypto.randomBytes(6).toString('hex'), token = crypto.randomBytes(16).toString('hex');
    fs.writeFileSync(path.join(FILES_DIR, id), buf);
    db.prepare('INSERT INTO files(id,name,size,token,mode,total,done,prog,created) VALUES(?,?,?,?,?,?,?,?,?)').run(id, name, buf.length, token, st.mode, st.total, st.done, st.prog || 0, Date.now());
    return send(res, 201, { id, name, size: buf.length, token, mode: st.mode, total: st.total, done: st.done, prog: st.prog || 0 });
  }

  if (p === '/api/data' && method === 'GET') return send(res, 200, allData());

  let m;
  if (p === '/api/items' && method === 'POST') {
    const o = cleanItem(await readBody(req)); o.id = nextIds(1)[0]; insItem(o); return send(res, 201, o);
  }
  if ((m = p.match(/^\/api\/items\/([^/]+)$/))) {
    const id = decodeURIComponent(m[1]); const cur = db.prepare('SELECT * FROM items WHERE id=?').get(id);
    if (!cur) bad('Temuan tidak ditemukan', 404);
    if (method === 'PUT') { const o = cleanItem(await readBody(req), { ...cur }); o.id = id; insItem(o); if ((cur.file || '') !== o.file) rmFile(cur.file); return send(res, 200, o); }
    if (method === 'DELETE') { db.prepare('DELETE FROM items WHERE id=?').run(id); rmFile(cur.file); return send(res, 200, { ok: true }); }
  }
  if (p === '/api/fu' && method === 'POST') {
    const o = cleanFu(await readBody(req)); if (dupFu(o)) bad(`Follow Up Audit Q${o.kuartal} ${o.tahun} sudah ada`, 409);
    o.id = 'f' + crypto.randomBytes(5).toString('hex'); insFu(o); return send(res, 201, o);
  }
  if ((m = p.match(/^\/api\/fu\/([^/]+)$/))) {
    const id = decodeURIComponent(m[1]); const cur = db.prepare('SELECT * FROM fu WHERE id=?').get(id);
    if (!cur) bad('Follow Up Audit tidak ditemukan', 404);
    if (method === 'PUT') { const o = cleanFu(await readBody(req), { ...cur }); o.id = id; if (dupFu(o, id)) bad(`Follow Up Audit Q${o.kuartal} ${o.tahun} sudah ada`, 409); insFu(o); return send(res, 200, o); }
    if (method === 'DELETE') {
      if (me.role !== 'admin') bad('Hanya admin yang boleh menghapus Follow Up Audit', 403);
      tx(() => { db.prepare('DELETE FROM items WHERE fu=?').run(id); db.prepare('DELETE FROM fu WHERE id=?').run(id); }); gcFiles(10 * 60e3); return send(res, 200, { ok: true });
    }
  }
  if (p === '/api/kebun' && method === 'POST') {
    const o = cleanKebun(await readBody(req)); o.id = 'k' + crypto.randomBytes(5).toString('hex'); insKebun(o); return send(res, 201, o);
  }
  if ((m = p.match(/^\/api\/kebun\/([^/]+)$/))) {
    const id = decodeURIComponent(m[1]); const cur = db.prepare('SELECT * FROM kebun WHERE id=?').get(id);
    if (!cur) bad('Kebun tidak ditemukan', 404);
    if (method === 'PUT') { const o = cleanKebun(await readBody(req), { ...cur }); o.id = id; insKebun(o); return send(res, 200, o); }
    if (method === 'DELETE') { tx(() => { db.prepare('DELETE FROM items WHERE kebun=?').run(id); db.prepare('DELETE FROM kebun WHERE id=?').run(id); }); gcFiles(10 * 60e3); return send(res, 200, { ok: true }); }
  }
  if (p === '/api/bulk' && method === 'POST') {
    const b = await readBody(req);
    const kebun = Array.isArray(b.kebun) ? b.kebun : [], items = Array.isArray(b.items) ? b.items : [], fus = Array.isArray(b.fu) ? b.fu : [];
    if (fus.length > 200) bad('Terlalu banyak periode sekaligus', 413);
    if (kebun.length > 1000 || items.length > 10000) bad('Terlalu banyak data sekaligus', 413);
    if (b.replace && me.role !== 'admin') bad('Hanya admin yang boleh mengganti seluruh data', 403);
    tx(() => {
      if (b.replace) { db.exec('DELETE FROM items; DELETE FROM kebun; DELETE FROM fu;'); }
      for (const f of fus) { const o = cleanFu(f); if (dupFu(o)) bad(`Follow Up Audit Q${o.kuartal} ${o.tahun} sudah ada`, 409); o.id = str(f.id, 60) || 'f' + crypto.randomBytes(5).toString('hex'); insFu(o); }
      for (const k of kebun) { const o = cleanKebun(k); o.id = str(k.id, 60) || 'k' + crypto.randomBytes(5).toString('hex'); insKebun(o); }
      const ids = nextIds(items.length);
      items.forEach((it, i) => { const o = cleanItem(it); o.id = (b.replace && str(it.id, 40)) || ids[i]; insItem(o); });
    });
    if (b.replace) gcFiles(10 * 60e3);
    return send(res, 200, { ok: true, kebun: kebun.length, items: items.length, fu: fus.length });
  }

  // manajemen pengguna (admin)
  if (p.startsWith('/api/users')) {
    if (me.role !== 'admin') bad('Hanya admin', 403);
    if (p === '/api/users' && method === 'GET') return send(res, 200, db.prepare('SELECT id,username,name,role FROM users ORDER BY id').all().map(r => ({ ...r })));
    if (p === '/api/users' && method === 'POST') { const b = await readBody(req); createUser(b.username, b.name, b.password, b.role); return send(res, 201, { ok: true }); }
    if ((m = p.match(/^\/api\/users\/(\d+)$/)) && method === 'DELETE') {
      const id = +m[1]; if (id === me.id) bad('Tidak bisa menghapus akun sendiri');
      const adm = db.prepare("SELECT COUNT(*) c FROM users WHERE role='admin' AND id<>?").get(id).c; const t = db.prepare('SELECT role FROM users WHERE id=?').get(id);
      if (t && t.role === 'admin' && adm < 1) bad('Harus ada minimal satu admin');
      db.prepare('DELETE FROM sessions WHERE user_id=?').run(id); db.prepare('DELETE FROM users WHERE id=?').run(id); return send(res, 200, { ok: true });
    }
    if ((m = p.match(/^\/api\/users\/(\d+)\/password$/)) && method === 'PUT') { const b = await readBody(req); setPassword(+m[1], b.password); return send(res, 200, { ok: true }); }
  }
  bad('Tidak ditemukan', 404);
}

/* ---------- unduh berkas lewat tautan (tanpa login; token acak 32 hex) ---------- */
function serveFile(req, res, url) {
  const m = url.pathname.match(/^\/f\/([a-f0-9]{32})(?:\/.*)?$/);
  const f = m && db.prepare('SELECT id,name,size FROM files WHERE token=?').get(m[1]);
  const fp = f && path.join(FILES_DIR, f.id);
  if (!f || !fs.existsSync(fp)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' }); return res.end('Berkas tidak ditemukan atau sudah dihapus'); }
  res.writeHead(200, {
    'Content-Type': 'application/octet-stream', 'Content-Length': f.size,
    'Content-Disposition': "attachment; filename*=UTF-8''" + encodeURIComponent(f.name).replace(/['()]/g, escape),
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
  });
  fs.createReadStream(fp).pipe(res);
}

/* ---------- static ---------- */
const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const SEC = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; script-src 'self'; connect-src 'self'; frame-ancestors 'none'",
};
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname); if (p === '/') p = '/index.html';
  const file = path.join(PUBLIC, path.normalize(p));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', ...SEC }); return res.end('Tidak ditemukan'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', ...SEC });
    res.end(data);
  });
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (url.pathname.startsWith('/f/') && req.method === 'GET') return serveFile(req, res, url);
    return serveStatic(req, res, url);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.code, { error: e.message });
    console.error(e); return send(res, 500, { error: 'Kesalahan server' });
  }
}).listen(PORT, HOST, () => console.log(`Audit Follow Up berjalan di http://localhost:${PORT}  (database: ${DB_PATH})`));
