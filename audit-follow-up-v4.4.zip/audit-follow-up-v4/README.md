# Audit Follow Up v4.4 (database + login + berkas + sidebar lipat + triwulan + animasi)

Server Node.js + database SQLite + login. Tanpa `npm install` (memakai SQLite bawaan Node).
**Syarat: Node.js 22.13 atau lebih baru.**

## Menjalankan
```
cd audit-follow-up-v4
node server.js
```
Buka http://localhost:3000.

Saat pertama kali dijalankan, akun admin dibuat otomatis dan **password-nya tampil di jendela terminal**:
```
username : admin
password : (acak, tertulis di terminal)
```
Ingin password sendiri? `set ADMIN_PASSWORD=PasswordKuat123&& node server.js` (Windows CMD) atau
`ADMIN_PASSWORD=PasswordKuat123 node server.js` (Mac/Linux). Hanya berlaku saat database masih kosong.

Lalu: masuk → **Pengaturan** → *Ganti kata sandi*. Tambah akun rekan di menu **Pengguna**.
Untuk melihat contoh tampilan: **Pengaturan → Muat data contoh** (menimpa semua data).

## Baru di v4.4

### % Progres manual per temuan
Form Tambah/Ubah temuan punya isian **% Progres (manual, 0–100)**. Persentase di samping status ditentukan dengan urutan:
1. Ada berkas Excel/CSV dengan kolom Status → dihitung otomatis dari poin selesai.
2. Status temuan **Selesai** → 100%.
3. Angka **% Progres** yang diisi manual.
4. Belum ada semuanya → tampil `–`.
Kolom **Persentase** juga ikut diekspor dan dikenali saat impor (alias: % Progres, Persen, Progres). Kolom baru ditambahkan otomatis ke database lama.

## Baru di v4.3

### Tim Auditor (penanggung jawab temuan)
Setiap temuan punya kolom **Tim Auditor**, tampil di samping **Kebun** pada halaman Temuan audit dan tabel Perlu perhatian di Ringkasan (juga di rincian Follow Up). Diisi di form Tambah/Ubah temuan, dengan saran dari nama yang pernah dipakai. Bisa dicari lewat kolom pencarian, ikut diekspor, dan dikenali saat impor lewat kolom **Tim Auditor** (alias: Auditor, Tim Audit). Kolom otomatis ditambahkan ke database lama.

## Baru di v4.2

### Animasi halus
- Jendela (modal) muncul dengan fade + naik sedikit, dan menutup dengan animasi; di HP tampil sebagai lembar yang meluncur dari bawah.
- Saat pindah menu, kartu, tabel, dan bar progres muncul bertahap. Animasi ini **hanya** jalan saat pindah halaman, bukan saat mengetik di kolom cari atau saat data diperbarui otomatis, supaya tidak berkedip.
- Menu •••, laci menu HP, kartu Follow Up (naik saat di-hover), tombol (efek tekan), dan baris tabel (sorot saat di-hover) ikut dihaluskan.
- Otomatis dimatikan bagi pengguna yang mengaktifkan *Reduce motion* di sistem operasinya.

## Baru di v4.1

### Triwulan (menggantikan kuartal)
Istilah *kuartal* diganti **Triwulan**, tetap berlabel Q1, Q2, Q3:

| Triwulan | Bulan |
|---|---|
| Q1 | September – Desember |
| Q2 | Januari – April |
| Q3 | Mei – Agustus |

Kolom **Tahun** kini berarti *tahun buku* (tahun mulai September): **Q1 2026/2027** = Sep–Des 2026, sedangkan Q2 dan Q3 2026/2027 jatuh di 2027. Di form tersedia petunjuk bulan yang diperbarui otomatis.
- Impor: kolom Periode menerima `Q1 2026/2027`, `Q1 2026`, `Triwulan 2 2026`, `2026/2027 Q3`. `Q4` tidak lagi dikenali.
- **Data lama otomatis dikonversi** saat server pertama kali jalan: periode kalender lama dipetakan lewat bulan tengahnya (Q4 lama → Q1 baru, Q1 lama → Q2 baru, Q2 dan Q3 lama → Q3 baru). Periode yang bertabrakan digabung, temuan ikut pindah. **Cadangkan folder `data` sebelum upgrade.**

### Persentase selesai per temuan
Di samping status tiap temuan tampil cincin kecil + persen (poin selesai ÷ total poin di berkas temuan itu). Tanpa kolom Status di Excel, persen tidak bisa dihitung (tampil `–`), kecuali temuan sudah ditandai Selesai (100%).

### Berkas & poin: selesai, sedang progres, tidak ada progres
Isi kolom **Status** di Excel dibaca menjadi tiga kelompok:
- **Selesai**: Selesai, Done, Closed, Tuntas, Sudah, 100%, dst.
- **Sedang progres**: Dalam proses, Proses, Sebagian, On going, Dikerjakan, Menunggu verifikasi, persen 1–99%, dst.
- **Tidak ada progres**: Belum, Belum ada progres, Belum diproses, Tidak ada progres, Open, Pending, atau sel kosong.
Berkas yang sudah diunggah sebelumnya dihitung ulang otomatis sekali saat server dijalankan.

## Baru di v4

### Berkas pendukung per temuan (Excel / Word, maks. 50 MB)
Di form **Tambah / Ubah temuan** ada bidang *Berkas pendukung*: pilih atau seret file `.xlsx`, `.xlsm`, `.xls`, `.csv`, `.docx`, `.doc` (maks. **50 MB**). Ada bar progres unggahan.
- Berkas disimpan di folder `data/files/` (ikut dicadangkan bersama `data/audit.db`). Satu temuan = satu berkas; **Ganti** / **Hapus** ada di form. Berkas ikut terhapus saat temuannya dihapus atau diganti.
- Bisa **diunduh** dari form, dari baris temuan (nama file berwarna hijau), atau dari menu ••• → *Berkas & poin*.
- **Hubungi PIC** (dan *Kirim ke PIC*) membuka WhatsApp dengan pesan pengingat yang sudah memuat **tautan unduh berkas**. WhatsApp Web tidak bisa melampirkan file otomatis dari web, jadi file dikirim sebagai tautan. Tautan memakai token acak dan **bisa dibuka tanpa login oleh siapa pun yang punya tautannya** (selama bisa menjangkau server). Jangan unggah dokumen yang terlalu rahasia.
- Bila aplikasi dibuka lewat `localhost`, tautan otomatis memakai IP jaringan kantor server. Kalau salah, atur di **Pengaturan → Alamat tautan berkas** (mis. `http://192.168.1.10:3000`; tersimpan per browser).

### Total poin, selesai, belum selesai, persentase (otomatis dari Excel)
Untuk file `.xlsx` / `.csv`, server membaca **sheet pertama**:
- Mencari kolom berjudul **Status** (juga *Progress*, *Selesai*, *Done*) di 15 baris pertama.
- Tiap baris yang berisi data dihitung sebagai 1 poin (baris "Total/Jumlah" dan baris kosong dilewati).
- Dianggap **selesai** bila Status berisi: Selesai, Done, Closed, Tuntas, Completed, Sudah, Ya, OK, ✓, 100%, 1. Nilai seperti *Belum*, *Dalam proses*, *Open*, *Pending*, kosong dihitung **belum selesai**.
- Hasil tampil di form, di bawah judul temuan (bar + `3/6 poin`), di rincian Follow Up, dan jumlahnya di kartu triwulan.
- Tidak ada kolom Status → hanya Total poin yang tampil, dengan petunjuk. File Word / `.xls` lama: tidak ada statistik.
- Mengubah isi Excel? Unggah ulang lewat **Ganti** agar angkanya diperbarui.

### Sidebar bisa diperkecil / diperbesar
Tombol panah di tepi sidebar (desktop) memperkecil menu menjadi ikon saja dan memperbesarnya lagi, dengan animasi halus. Pilihan diingat per browser. Di HP/tablet menu tetap berupa laci ☰.

### Upgrade dari v3 / v2
Ekstrak zip ke folder lama (timpa file), **jangan hapus folder `data`**. Kolom dan tabel baru dibuat otomatis.

## Follow Up Audit per triwulan
Struktur data: **Follow Up Audit (Q1–Q3 + tahun buku) → Kebun → Bagian (Inventory, K3, dll.) → Temuan**.
- Pilih periode di bagian atas layar; Ringkasan, Temuan, Kebun & PIC, dan Pengingat mengikuti periode itu ("Semua periode" menampilkan semuanya). Pilihan diingat per browser.
- Menu **Follow Up Audit**: kartu tiap kuartal (progres selesai) dan rincian berupa pohon kebun → bagian. Tombol **+ Temuan** di tiap kebun/bagian mengisi form otomatis.
- **Bagian** diketik bebas dengan saran (Inventory, Aset Tetap, Kas & Bank, K3, …) ditambah bagian yang pernah dipakai.
- Semua pengguna boleh membuat/mengubah Follow Up; **hanya admin yang boleh menghapus** (temuan di dalamnya ikut terhapus).
- Impor/ekspor punya kolom **Periode** (mis. `Q1 2026/2027`, `Triwulan 2 2026`, `Triwulan III 2026`) dan **Bagian**. Periode yang belum ada dibuat otomatis; kolom kosong memakai periode yang sedang dipilih.

### Upgrade dari versi sebelumnya
Ekstrak zip ke folder lama (timpa file), **jangan hapus folder `data`**. Temuan lama otomatis dimasukkan ke Follow Up Audit kuartal berjalan; kolom "Kategori" lama menjadi "Bagian".

## Tampilan desktop & HP
Tampilan menyesuaikan otomatis: di desktop menu ada di kiri; di tablet/HP menu menjadi laci yang dibuka dengan tombol ☰, tabel berubah menjadi kartu, dan formulir tampil dari bawah layar. Sudah diuji di lebar 1280, 820, dan 390 px.

## Impor Excel
Menu **Impor & ekspor** menerima file **.xlsx** atau **.csv** (maks. 10 MB untuk impor data temuan). Alurnya: pilih file → lihat **pratinjau** (jumlah baris, kebun baru, peringatan) → klik *Impor*.
- Judul kolom boleh di baris mana pun dalam 10 baris pertama; nama kolom dikenali dengan beberapa alias (mis. *Uraian*, *Tenggat*, *Priority*).
- Tanggal dikenali dari sel tanggal Excel, `2026-12-05`, `15/12/2026`, atau `5 Des 2026`.
- Baris yang sama persis (deskripsi + kebun + jatuh tempo) dilewati; kebun yang belum ada dibuat otomatis.
- Format `.xls` lama belum didukung: buka di Excel lalu *Simpan Sebagai* `.xlsx`. Unduh template CSV dari halaman yang sama.

## Variabel lingkungan
| Nama | Fungsi | Bawaan |
|---|---|---|
| `PORT` | Port server | 3000 |
| `HOST` | Alamat bind | 0.0.0.0 |
| `DB_PATH` | Lokasi file database | `./data/audit.db` |
| `ADMIN_PASSWORD` | Password admin awal | acak |
| `COOKIE_SECURE=1` | Paksa cookie hanya via HTTPS | otomatis jika di belakang proxy HTTPS |

## Cadangan
Seluruh data ada di satu file: `data/audit.db` (plus `audit.db-wal` / `audit.db-shm` saat server jalan).
Hentikan server lalu salin folder `data/` secara berkala. Bisa juga ekspor CSV dari menu Impor & ekspor.

## Memasang online
Server wajib di belakang **HTTPS** (hosting PaaS/Caddy/Nginx menyediakannya).
- **Render / Railway / Fly.io**: buat Web Service dari folder ini, start command `node server.js`, set `NODE_VERSION=22` (atau lebih baru),
  dan pasang **persistent disk** yang di-mount ke mis. `/var/data`, lalu set `DB_PATH=/var/data/audit.db`.
  Tanpa disk persisten, database akan hilang setiap deploy/restart.
- **VPS**: pasang Node 22+, jalankan dengan `pm2` atau `systemd`, dan taruh Caddy/Nginx di depannya untuk HTTPS.
- Set `ADMIN_PASSWORD` kuat sebelum jalan pertama kali.

## Keamanan yang sudah ada
Kata sandi di-hash (scrypt), sesi lewat cookie HttpOnly, pembatasan percobaan login, proteksi CSRF dasar,
header keamanan + CSP, file server/database tidak bisa diunduh dari web.
Belum ada: reset sandi lewat email, 2FA, log audit. Peran saat ini hanya *Admin* (kelola akun, ganti seluruh data) dan *Pengguna* (kelola temuan/kebun).
